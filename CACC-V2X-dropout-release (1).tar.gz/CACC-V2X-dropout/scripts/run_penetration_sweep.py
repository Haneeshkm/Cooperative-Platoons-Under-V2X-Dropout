#!/usr/bin/env python3
"""
Reproduce the mixed-autonomy penetration sweep (Section "Learned Controller"
-- "Robustness across penetration and bursty loss").

Note: an earlier, unpublished version of this sweep (run against a training
pipeline with an RNG-continuity bug -- see CORRECTIONS.md) reported a seed
that catastrophically destabilised specifically under partial penetration.
That finding did NOT reproduce once the bug was fixed and the seed retrained;
it is documented in CORRECTIONS.md as a cautionary example, not reproduced by
this script. Non-controlled followers are IDM human drivers.

Usage:
    python scripts/run_penetration_sweep.py
"""
from __future__ import annotations
import argparse
import json
import os

import torch

from cacc.evaluation import evaluate, make_rl_controllers, load_actor

DEFAULT_PENETRATIONS = [1.0, 0.75, 0.5, 0.25]


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--seeds", type=int, nargs="+", default=[10, 11, 12, 13, 14])
    p.add_argument("--model-dir", default="models")
    p.add_argument("--variant", default="full_gate")
    p.add_argument("--penetrations", type=float, nargs="+", default=DEFAULT_PENETRATIONS)
    p.add_argument("--p-drop", type=float, default=0.3)
    p.add_argument("--out", default="results/penetration_sweep/sweep.json")
    args = p.parse_args()

    torch.set_num_threads(1)
    results: dict = {}
    for seed in args.seeds:
        actor = load_actor(f"{args.model_dir}/{args.variant}_seed{seed}.pt")
        results[str(seed)] = {}
        for pen in args.penetrations:
            r = evaluate(lambda n: make_rl_controllers(actor, n), penetration=pen,
                         p_drop=args.p_drop)
            results[str(seed)][f"pen={pen}"] = r.as_dict()
            print(f"seed={seed} penetration={pen:.2f}  Gamma*={r.gamma_mean:.3f}"
                  f"+/-{r.gamma_std:.3f} f_stable={r.f_stable:.2f}")

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w") as f:
        json.dump(results, f, indent=2)
    print(f"Saved -> {args.out}")


if __name__ == "__main__":
    main()
