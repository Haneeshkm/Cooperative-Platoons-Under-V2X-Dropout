#!/usr/bin/env python3
"""
Reproduce the disturbance-frequency sensitivity sweep (Section "Learned
Controller" -- "Frequency and platoon-length sensitivity"; also used for
Threats to Validity's frequency-band discussion).

Sweeps the disturbance frequency omega at fixed p=0.3, comparing the learned
controller (one representative seed by default), naive CACC, and the tuned
SmoothCACC scheduler.

Usage:
    python scripts/run_frequency_sweep.py --model models/full_gate_seed10.pt
"""
from __future__ import annotations
import argparse
import json
import os

import torch

from cacc.controllers import CACC, SmoothCACC
from cacc.evaluation import evaluate, make_rl_controllers, load_actor

DEFAULT_OMEGAS = [0.10, 0.20, 0.30, 0.45, 0.60, 0.80, 1.00, 1.30, 1.60]


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--model", default="models/full_gate_seed10.pt")
    p.add_argument("--omegas", type=float, nargs="+", default=DEFAULT_OMEGAS)
    p.add_argument("--p-drop", type=float, default=0.3)
    p.add_argument("--smooth-tau-r", type=float, default=2.0)
    p.add_argument("--smooth-kff", type=float, default=0.8)
    p.add_argument("--out", default="results/frequency_sweep/sweep.json")
    args = p.parse_args()

    torch.set_num_threads(1)
    actor = load_actor(args.model)
    results = {"omegas": args.omegas, "RL": [], "naive_CACC": [], "smooth_CACC_tuned": []}

    for om in args.omegas:
        # Low-frequency disturbances have long periods; scale T so the horizon
        # comfortably covers the >=3 periods steady_state_gamma's window needs
        # (matches the formula used to generate the paper's frequency-sweep figure).
        # Use the canonical T=120s (matching every other table in the paper) unless a
        # low frequency genuinely needs a longer horizon to contain >=3 disturbance
        # periods; never SHORTER than canonical, so the omega=0.45 point here is
        # identical in protocol to the main benchmark tables.
        from cacc.evaluation import CANONICAL_T
        T = max(CANONICAL_T, 4.5 * (2 * 3.14159 / om))
        r_rl = evaluate(lambda n: make_rl_controllers(actor, n), omega=om, p_drop=args.p_drop, T=T)
        r_naive = evaluate(lambda n: [CACC() for _ in range(n)], omega=om, p_drop=args.p_drop, T=T)
        r_smooth = evaluate(lambda n: [SmoothCACC(tau_r=args.smooth_tau_r, kff=args.smooth_kff)
                                        for _ in range(n)], omega=om, p_drop=args.p_drop, T=T)
        results["RL"].append(r_rl.as_dict())
        results["naive_CACC"].append(r_naive.as_dict())
        results["smooth_CACC_tuned"].append(r_smooth.as_dict())
        print(f"omega={om:.2f} (T_p={2*3.14159/om:.1f}s)  "
              f"RL: Gamma*={r_rl.gamma_mean:.3f} f_stable={r_rl.f_stable:.2f}  |  "
              f"naive: {r_naive.gamma_mean:.3f}/{r_naive.f_stable:.2f}  |  "
              f"smooth: {r_smooth.gamma_mean:.3f}/{r_smooth.f_stable:.2f}")

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w") as f:
        json.dump(results, f, indent=2)
    print(f"Saved -> {args.out}")


if __name__ == "__main__":
    main()
