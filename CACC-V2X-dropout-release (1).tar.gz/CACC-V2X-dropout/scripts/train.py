#!/usr/bin/env python3
"""
Train one shared-policy multi-agent TD3 controller (Section "Dropout-Aware
Multi-Agent Reinforcement Learning" of the paper).

This script is deliberately resumable and time-budgeted rather than assuming
it can run to completion in one process: development of this project was done
under a hard per-command wall-clock limit, and rather than throw that
infrastructure away, it is kept here because it also solves a real problem --
long training runs on modest hardware benefit from checkpointing regardless of
where they run.

IMPORTANT -- reproducibility: every resume restores both the model/optimizer
state AND the global numpy/torch RNG state (see cacc.rng_checkpoint). Simply
reseeding with the same --seed on every invocation, without restoring the RNG
stream, silently produces a DIFFERENT training trajectory depending on where
the process happened to be paused and resumed (this project's own
CORRECTIONS.md documents a concrete case where it flipped a policy from
string-stable to string-unstable). test/test_reproducibility.py checks this
invariant directly; run it after modifying this script.

Usage:
    # cold start, run until the time budget or --episodes is reached
    python scripts/train.py --seed 10 --episodes 150 --time-budget 240

    # resume (same command; it detects the checkpoint automatically)
    python scripts/train.py --seed 10 --episodes 150 --time-budget 240

    # periodic snapshots every 20 episodes, for checkpoint-selection analysis
    # (see scripts/run_checkpoint_selection.py)
    python scripts/train.py --seed 10 --episodes 150 --snapshot-every 20

    # the gate-causality ablation variant (raw V2X fields withheld from the
    # actor after gating; see Section "Isolating the role of the gate")
    python scripts/train.py --seed 10 --episodes 150 --hide-raw-comm
"""
from __future__ import annotations
import argparse
import os
import time

import numpy as np
import torch

from cacc.marl_env import PlatoonMARLEnv, MARLConfig
from cacc.maddpg import MADDPG, ReplayBuffer
from cacc import scenarios, V2XParams


def build(seed: int, hide_raw_comm: bool, n_followers: int = 6):
    """Cold-start construction. Safe to call again on resume: build()'s own
    reseed is immediately overwritten by the RNG state restored from the
    checkpoint (see run_training below), so it never affects a resumed run."""
    np.random.seed(seed)
    torch.manual_seed(seed)
    mcfg = MARLConfig(n_followers=n_followers, penetration=1.0, T=40.0,
                       randomize_disturbance=True)
    env = PlatoonMARLEnv(mcfg, scenarios.highway_cruise(),
                          V2XParams(mode="bernoulli", p_drop=0.3, delay_steps=1),
                          rng=np.random.default_rng(seed), randomize_dropout=True)
    algo = MADDPG(env.n_agents, hide_raw_comm=hide_raw_comm)
    buf = ReplayBuffer(200_000, env.n_agents)
    return env, algo, buf


def run_one_episode(env, algo, buf, ep: int, seed: int, n_episodes: int) -> float:
    obs = env.reset(seed=seed * 10_000 + ep)
    arr = np.stack([obs[ai] for ai in env.agent_idx])
    noise = max(0.05, 0.25 - 0.20 * (ep / n_episodes))
    ep_return = 0.0
    while True:
        acts = algo.act(arr, noise=noise)
        nobs, rew, dones, info = env.step({ai: acts[j] for j, ai in enumerate(env.agent_idx)})
        narr = np.stack([nobs[ai] for ai in env.agent_idx])
        buf.push(arr, acts.astype(np.float32),
                  np.array([rew[ai] for ai in env.agent_idx], np.float32), narr,
                  np.array([float(dones[ai]) for ai in env.agent_idx], np.float32))
        algo.update(buf, batch=256)
        arr = narr
        ep_return += sum(rew.values()) / len(rew)
        if any(dones.values()):
            return ep_return


def save_checkpoint(path, algo, buf, ep_idx, ep_returns, hide_raw_comm, total_train_time):
    torch.save({
        "actor_state": algo.actor.state_dict(), "actor_t_state": algo.actor_t.state_dict(),
        "critic_state": algo.critic.state_dict(), "critic_t_state": algo.critic_t.state_dict(),
        "opt_a_state": algo.opt_a.state_dict(), "opt_c_state": algo.opt_c.state_dict(),
        "total_it": algo.total_it, "buf": buf.buf, "buf_pos": buf.pos,
        "ep_idx": ep_idx, "ep_returns": ep_returns, "hide_raw_comm": hide_raw_comm,
        "total_train_time": total_train_time,
        # Global RNG state -- see the reproducibility note in the module docstring.
        "np_random_state": np.random.get_state(),
        "torch_random_state": torch.get_rng_state(),
    }, path)


def load_checkpoint(path, algo, buf):
    ck = torch.load(path, weights_only=False)
    algo.actor.load_state_dict(ck["actor_state"])
    algo.actor_t.load_state_dict(ck["actor_t_state"])
    algo.critic.load_state_dict(ck["critic_state"])
    algo.critic_t.load_state_dict(ck["critic_t_state"])
    algo.opt_a.load_state_dict(ck["opt_a_state"])
    algo.opt_c.load_state_dict(ck["opt_c_state"])
    algo.total_it = ck["total_it"]
    buf.buf = ck["buf"]
    buf.pos = ck["buf_pos"]
    # Restore RNG state LAST, after build()'s cold-start reseed, so the noise /
    # replay-sampling / target-smoothing stream actually continues rather than
    # repeating from the seed at every resume.
    np.random.set_state(ck["np_random_state"])
    torch.set_rng_state(ck["torch_random_state"])
    return ck["ep_idx"], ck["ep_returns"], ck["total_train_time"]


def run_training(seed: int, variant: str, n_episodes: int, time_budget: float,
                  snapshot_every: int | None, model_dir: str, ckpt_dir: str,
                  snapshot_dir: str) -> None:
    hide_raw_comm = variant == "hide_raw_comm"
    final_path = os.path.join(model_dir, f"{variant}_seed{seed}.pt")
    ckpt_path = os.path.join(ckpt_dir, f"{variant}_seed{seed}.pt")
    os.makedirs(model_dir, exist_ok=True)
    os.makedirs(ckpt_dir, exist_ok=True)
    if snapshot_every:
        os.makedirs(snapshot_dir, exist_ok=True)

    if os.path.exists(final_path):
        print(f"[already complete] {final_path}")
        return

    env, algo, buf = build(seed, hide_raw_comm)
    if os.path.exists(ckpt_path):
        ep, ep_returns, total_time = load_checkpoint(ckpt_path, algo, buf)
        print(f"[resume] {variant} seed={seed} from episode {ep}/{n_episodes} "
              f"(replay buffer size {len(buf)})")
    else:
        ep, ep_returns, total_time = 0, [], 0.0
        print(f"[start] {variant} seed={seed}")

    # With --snapshot-every, stop at the next snapshot boundary even if there's
    # time budget left, so snapshots land on round episode counts.
    target = n_episodes
    if snapshot_every:
        target = min(n_episodes, ((ep // snapshot_every) + 1) * snapshot_every)

    t0 = time.time()
    while ep < target and (time.time() - t0) < time_budget:
        ep_returns.append(run_one_episode(env, algo, buf, ep, seed, n_episodes))
        ep += 1
    elapsed = time.time() - t0
    total_time += elapsed

    if snapshot_every and ep % snapshot_every == 0 and ep > 0:
        snap_path = os.path.join(snapshot_dir, f"{variant}_seed{seed}_ep{ep}.pt")
        torch.save({"actor_state": algo.actor.state_dict(), "hide_raw_comm": hide_raw_comm,
                    "episode": ep, "ep_returns": list(ep_returns)}, snap_path)
        print(f"  -> snapshot saved: {snap_path}")

    if ep >= n_episodes:
        torch.save({"actor_state": algo.actor.state_dict(), "hide_raw_comm": hide_raw_comm,
                    "ep_returns": ep_returns, "train_time_s": total_time}, final_path)
        if os.path.exists(ckpt_path):
            os.remove(ckpt_path)
        print(f"[COMPLETE] {variant} seed={seed}: {ep} episodes, {total_time:.1f}s total, "
              f"return first10={np.mean(ep_returns[:10]):.1f} "
              f"last10={np.mean(ep_returns[-10:]):.1f} -> {final_path}")
    else:
        save_checkpoint(ckpt_path, algo, buf, ep, ep_returns, hide_raw_comm, total_time)
        print(f"[checkpoint] {variant} seed={seed}: {ep}/{n_episodes} episodes done "
              f"({elapsed:.1f}s this run, {total_time:.1f}s total, "
              f"recent return={np.mean(ep_returns[-5:]):.1f}) -> {ckpt_path}")
        print("  Run this command again to continue training.")


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--seed", type=int, required=True)
    p.add_argument("--variant", choices=["full_gate", "hide_raw_comm"], default="full_gate")
    p.add_argument("--episodes", type=int, default=150,
                    help="Total training episodes (paper's featured run uses ~255; "
                         "150 is the reduced budget used for this project's own "
                         "compute-constrained reproduction -- see CORRECTIONS.md).")
    p.add_argument("--time-budget", type=float, default=240.0,
                    help="Wall-clock seconds to train before checkpointing and exiting.")
    p.add_argument("--snapshot-every", type=int, default=None,
                    help="If set, save a periodic actor-only snapshot every N "
                         "episodes (for scripts/run_checkpoint_selection.py).")
    p.add_argument("--model-dir", default="models")
    p.add_argument("--ckpt-dir", default="checkpoints")
    p.add_argument("--snapshot-dir", default="snapshots")
    args = p.parse_args()

    torch.set_num_threads(1)  # ~4x faster on a single-core machine than the default
    run_training(args.seed, args.variant, args.episodes, args.time_budget,
                 args.snapshot_every, args.model_dir, args.ckpt_dir, args.snapshot_dir)


if __name__ == "__main__":
    main()
