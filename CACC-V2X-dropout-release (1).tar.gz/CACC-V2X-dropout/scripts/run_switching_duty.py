#!/usr/bin/env python3
"""
Reproduce the switching-prevalence-versus-structural-isolation sub-grid (Section
"Mixed-autonomy topology, penetration, and switching prevalence").

Measures, for the naive additive-feedforward CACC baseline, the mean fraction of time
controlled vehicles spend without a received message (p_fallback) and the mean number
of link-state toggles per controlled vehicle per minute, over a representative
(rho, p) sub-grid -- distinguishing genuine intermittent channel-driven fallback
(high toggle rate) from permanent structural isolation (low toggle rate despite high
p_fallback).

Usage:
    python scripts/run_switching_duty.py
"""
from __future__ import annotations
import argparse
import json
import os

import numpy as np

from cacc.controllers import CACC
from cacc.platoon import Platoon, PlatoonConfig
from cacc.v2x import V2XParams
from cacc.idm import sample_idm_population
from cacc import scenarios
from cacc.evaluation import build_mixed_types, CANONICAL_EVAL_SEEDS

OMEGA = 0.45
DT = 0.1
T = 120.0
N = 8


def switching_stats(penetration, p_drop, seeds=CANONICAL_EVAL_SEEDS, n=N):
    lead = scenarios.highway_cruise(v=25.0, amp=3.0, period=2 * np.pi / OMEGA)
    toggle_rates, fallback_fracs = [], []
    for s in seeds:
        rng = np.random.default_rng(s)
        types = (["controlled"] * n if penetration >= 1.0
                 else build_mixed_types(n, penetration, rng))
        controllers = [CACC() if t == "controlled" else None for t in types]
        cfg = PlatoonConfig(n_followers=n, dt=DT, T=T, init_gap=20.0, init_speed=25.0)
        pl = Platoon(cfg, lead, types, controllers,
                     human_params=sample_idm_population(n, rng),
                     v2x_params=V2XParams(mode="bernoulli", p_drop=p_drop, delay_steps=1),
                     rng=rng)
        log = pl.run()
        recv = log["v2x_received"]
        ctrl_idx = [i for i, t in enumerate(types) if t == "controlled"]
        if not ctrl_idx:
            continue
        recv_c = recv[:, ctrl_idx]
        toggles = np.abs(np.diff(recv_c.astype(int), axis=0)).sum(axis=0)
        toggle_rates.append(float(np.mean(toggles) / (recv_c.shape[0] * DT) * 60.0))
        fallback_fracs.append(float(1.0 - recv_c.mean()))
    return float(np.mean(toggle_rates)), float(np.mean(fallback_fracs))


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--rhos", type=float, nargs="+", default=[0.25, 0.5, 1.0])
    p.add_argument("--ps", type=float, nargs="+", default=[0.1, 0.3, 0.6])
    p.add_argument("--out", default="results/switching_duty/sweep.json")
    args = p.parse_args()

    results = []
    print(f"{'penetration':>12} {'p_drop':>8} {'toggle/min':>12} {'fallback_frac':>14}")
    for rho in args.rhos:
        for pd in args.ps:
            tr, ff = switching_stats(rho, pd)
            results.append({"rho": rho, "p_drop": pd, "toggle_rate_per_min": tr,
                             "fallback_frac": ff})
            print(f"{rho:>12.2f} {pd:>8.2f} {tr:>12.2f} {ff:>14.3f}")

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved -> {args.out}")


if __name__ == "__main__":
    main()
