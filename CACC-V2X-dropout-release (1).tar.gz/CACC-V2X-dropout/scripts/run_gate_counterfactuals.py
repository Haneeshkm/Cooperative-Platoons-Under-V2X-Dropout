import sys, json
sys.path.insert(0, '.')
import numpy as np
import torch
torch.set_num_threads(1)

from cacc.evaluation import evaluate, forced_gate_actor_fn, load_actor, CANONICAL_EVAL_SEEDS
from cacc.controllers import RLPolicy
from cacc.marl_env import OBS_KEYS
from cacc.maddpg import I_A_LEAD_ONBOARD, I_V2X_A

DT = 0.1


def handdesigned_gate_actor_fn(actor, tau_r_steps=5.0):
    """g(beta, alpha) = exp(-age/tau_r), same functional form as SmoothCACC's
    reliability weight, but feeding the trained policy net instead of a classical
    control law -- benchmarks whether ANY age-aware adaptivity suffices, or whether
    the specific LEARNED gate is doing something a simple hand rule can't."""
    keep_idx = actor._keep_idx
    msg_age_idx = OBS_KEYS.index("msg_age")
    def fn(obs_vec):
        with torch.no_grad():
            o = torch.as_tensor(obs_vec, dtype=torch.float32).unsqueeze(0)
            age_norm = o[..., msg_age_idx:msg_age_idx + 1]  # normalised [0,1] over 20 steps
            age_steps = age_norm * 20.0
            g = torch.exp(-age_steps / tau_r_steps)
            a_lead_eff = g * o[..., I_V2X_A:I_V2X_A + 1] + \
                (1 - g) * o[..., I_A_LEAD_ONBOARD:I_A_LEAD_ONBOARD + 1]
            obs_in = o[..., keep_idx]
            x = torch.cat([obs_in, a_lead_eff], dim=-1)
            return actor.net(x).cpu().numpy().ravel()
    return fn


if __name__ == "__main__":
    results = {}
    for pd in (0.3, 0.6):
        results[f"p={pd}"] = {}
        for seed in (10, 11, 12, 13, 14):
            actor = load_actor(f"models/full_gate_seed{seed}.pt")
            entry = {}
            for c in (0.25, 0.5, 0.75):
                r = evaluate(lambda n: [RLPolicy(forced_gate_actor_fn(actor, c), OBS_KEYS)
                                          for _ in range(n)], p_drop=pd)
                entry[f"g={c}"] = r.as_dict()
            r = evaluate(lambda n: [RLPolicy(handdesigned_gate_actor_fn(actor), OBS_KEYS)
                                      for _ in range(n)], p_drop=pd)
            entry["handdesigned_expdecay"] = r.as_dict()
            results[f"p={pd}"][str(seed)] = entry
            print(f"p={pd} seed={seed}: " +
                  "  ".join(f"{k}={v['gamma_mean']:.3f}(fs={v['f_stable']:.1f})"
                            for k, v in entry.items()))

    with open("results/gate_ablation/gate_counterfactuals.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\nSaved -> results/gate_ablation/gate_counterfactuals.json")
