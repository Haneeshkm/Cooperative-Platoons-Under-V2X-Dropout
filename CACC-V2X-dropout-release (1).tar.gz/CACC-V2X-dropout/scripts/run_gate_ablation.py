#!/usr/bin/env python3
"""
Reproduce the gate-isolation ablation (Table "Isolating the gate", Section
"Learned Controller: String-Stable CACC under Dropout").

For each trained seed, evaluates the adaptive gate against the gate forced to
0 (onboard only) and 1 (always trust V2X) at both p=0.3 and p=0.6. Requires
models trained with scripts/train.py --variant full_gate for each seed listed
in --seeds (default: 10-14, matching the paper).

Usage:
    python scripts/run_gate_ablation.py
    python scripts/run_gate_ablation.py --seeds 10 11 12 --model-dir models
"""
from __future__ import annotations
import argparse
import json

import torch

from cacc.evaluation import evaluate, make_rl_controllers, forced_gate_actor_fn, load_actor
from cacc.controllers import RLPolicy
from cacc.marl_env import OBS_KEYS


def evaluate_seed(model_path: str, p_drop: float) -> dict:
    actor = load_actor(model_path)
    adaptive = evaluate(lambda n: make_rl_controllers(actor, n), p_drop=p_drop)
    g0 = evaluate(lambda n: [RLPolicy(forced_gate_actor_fn(actor, 0.0), OBS_KEYS)
                              for _ in range(n)], p_drop=p_drop)
    g1 = evaluate(lambda n: [RLPolicy(forced_gate_actor_fn(actor, 1.0), OBS_KEYS)
                              for _ in range(n)], p_drop=p_drop)
    return {"adaptive": adaptive.as_dict(), "forced_g0": g0.as_dict(), "forced_g1": g1.as_dict()}


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--seeds", type=int, nargs="+", default=[10, 11, 12, 13, 14])
    p.add_argument("--model-dir", default="models")
    p.add_argument("--variant", default="full_gate")
    p.add_argument("--p-drops", type=float, nargs="+", default=[0.3, 0.6])
    p.add_argument("--out", default="results/gate_ablation/gate_ablation.json")
    args = p.parse_args()

    torch.set_num_threads(1)
    results: dict = {}
    for pd in args.p_drops:
        pkey = f"p={pd}"
        results[pkey] = {}
        for seed in args.seeds:
            path = f"{args.model_dir}/{args.variant}_seed{seed}.pt"
            entry = evaluate_seed(path, pd)
            results[pkey][str(seed)] = entry
            a, g0, g1 = entry["adaptive"], entry["forced_g0"], entry["forced_g1"]
            print(f"[{pkey}] seed={seed}  adaptive={a['gamma_mean']:.3f}"
                  f"(f_s={a['f_stable']:.1f})  g0={g0['gamma_mean']:.3f}"
                  f"(f_s={g0['f_stable']:.1f})  g1={g1['gamma_mean']:.3f}"
                  f"(f_s={g1['f_stable']:.1f})")

    import os
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved -> {args.out}")

    # Reproduce the paper's headline stability count: (seed, dropout-rate) pairs
    # stable under each gate setting, across the seeds that converge to a
    # string-stable policy under the adaptive gate at both dropout rates.
    good_seeds = [s for s in args.seeds
                  if all(results[f"p={pd}"][str(s)]["adaptive"]["f_stable"] == 1.0
                         for pd in args.p_drops)]
    print(f"\nSeeds stable under the adaptive gate at every tested dropout rate: {good_seeds}")
    for variant in ("adaptive", "forced_g0", "forced_g1"):
        n_stable = sum(1 for s in good_seeds for pd in args.p_drops
                        if results[f"p={pd}"][str(s)][variant]["f_stable"] == 1.0)
        n_total = len(good_seeds) * len(args.p_drops)
        print(f"  {variant}: stable in {n_stable}/{n_total} (seed, dropout-rate) pairs")


if __name__ == "__main__":
    main()
