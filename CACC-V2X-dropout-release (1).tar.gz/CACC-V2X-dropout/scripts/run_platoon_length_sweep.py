#!/usr/bin/env python3
"""
Reproduce the platoon-length sensitivity sweep (Section "Learned Controller"
-- "Frequency and platoon-length sensitivity").

Usage:
    python scripts/run_platoon_length_sweep.py --model models/full_gate_seed10.pt
"""
from __future__ import annotations
import argparse
import json
import os

import torch

from cacc.controllers import CACC, SmoothCACC
from cacc.evaluation import evaluate, make_rl_controllers, load_actor

DEFAULT_LENGTHS = [4, 6, 8, 10, 14, 20]


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--model", default="models/full_gate_seed10.pt")
    p.add_argument("--lengths", type=int, nargs="+", default=DEFAULT_LENGTHS)
    p.add_argument("--p-drop", type=float, default=0.3)
    p.add_argument("--omega", type=float, default=0.45)
    p.add_argument("--out", default="results/platoon_length_sweep/sweep.json")
    args = p.parse_args()

    torch.set_num_threads(1)
    actor = load_actor(args.model)
    results = {"n_followers": args.lengths, "RL": [], "naive_CACC": [], "smooth_CACC_tuned": []}

    for n in args.lengths:
        r_rl = evaluate(lambda nn: make_rl_controllers(actor, nn), n_followers=n,
                         omega=args.omega, p_drop=args.p_drop)
        r_naive = evaluate(lambda nn: [CACC() for _ in range(nn)], n_followers=n,
                            omega=args.omega, p_drop=args.p_drop)
        r_smooth = evaluate(lambda nn: [SmoothCACC(tau_r=2.0, kff=0.8) for _ in range(nn)],
                             n_followers=n, omega=args.omega, p_drop=args.p_drop)
        results["RL"].append(r_rl.as_dict())
        results["naive_CACC"].append(r_naive.as_dict())
        results["smooth_CACC_tuned"].append(r_smooth.as_dict())
        print(f"n_followers={n:2d}  RL: Gamma*={r_rl.gamma_mean:.3f} f_stable={r_rl.f_stable:.2f}  |  "
              f"naive: {r_naive.gamma_mean:.3f}/{r_naive.f_stable:.2f}  |  "
              f"smooth: {r_smooth.gamma_mean:.3f}/{r_smooth.f_stable:.2f}")

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w") as f:
        json.dump(results, f, indent=2)
    print(f"Saved -> {args.out}")


if __name__ == "__main__":
    main()
