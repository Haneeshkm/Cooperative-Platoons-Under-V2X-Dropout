import sys, json
sys.path.insert(0, '.')
import numpy as np
import torch
torch.set_num_threads(1)

from cacc.controllers import CACC, SmoothCACC
from cacc.evaluation import (run_rollout, make_rl_controllers, load_actor,
                              CANONICAL_EVAL_SEEDS, CANONICAL_DT)


def full_metrics(make_controllers, p_drop, seeds=CANONICAL_EVAL_SEEDS, **kw):
    gammas, jerks, energies, min_gaps, min_ttcs, headways = [], [], [], [], [], []
    for s in seeds:
        r = run_rollout(make_controllers, s, p_drop=p_drop, **kw)
        log = r.log
        gap, vel = log["gap"], log["vel"]
        # same steady-state window as Gamma*
        omega = kw.get("omega", 0.45)
        T_p = 2 * np.pi / omega
        window = int(np.ceil(3 * T_p / CANONICAL_DT))
        k0 = max(0, gap.shape[0] - window)
        gap_w, vel_w = gap[k0:], vel[k0:]
        v_followers = vel_w[:, 1:]
        # TTC per follower per step
        closing = v_followers - vel_w[:, :-1]
        with np.errstate(divide="ignore", invalid="ignore"):
            ttc = np.where(closing > 1e-3, gap_w / closing, np.inf)
        gammas.append(r.gamma)
        jerks.append(r.jerk)
        energies.append(r.energy)
        min_gaps.append(float(gap_w.min()))
        min_ttcs.append(float(np.min(ttc[np.isfinite(ttc)])) if np.isfinite(ttc).any() else float("inf"))
        # effective time headway: mean(gap / v) over the steady window, per follower, averaged
        with np.errstate(divide="ignore", invalid="ignore"):
            th = gap_w / np.maximum(v_followers, 1e-3)
        headways.append(float(np.mean(th)))
    return {
        "gamma_mean": float(np.mean(gammas)), "gamma_std": float(np.std(gammas)),
        "f_stable": float(np.mean([g <= 1.0 + 1e-6 for g in gammas])),
        "jerk_mean": float(np.mean(jerks)), "energy_mean": float(np.mean(energies)),
        "min_gap_mean": float(np.mean(min_gaps)), "min_ttc_mean": float(np.mean(min_ttcs)),
        "effective_headway_s": float(np.mean(headways)),
    }


if __name__ == "__main__":
    results = {}
    for pd in (0.3, 0.6):
        entries = {}
        entries["naive_CACC"] = full_metrics(lambda n: [CACC() for _ in range(n)], pd)
        smooth_cfg = dict(tau_r=2.0, kff=0.8) if pd == 0.3 else dict(tau_r=2.0, kff=0.6)
        entries["smooth_CACC_tuned"] = full_metrics(
            lambda n: [SmoothCACC(**smooth_cfg) for _ in range(n)], pd)
        for seed in (10, 11, 12, 13, 14):
            actor = load_actor(f"models/full_gate_seed{seed}.pt")
            entries[f"RL_seed{seed}"] = full_metrics(
                lambda n, a=actor: make_rl_controllers(a, n), pd)
        results[f"p={pd}"] = entries
        print(f"\n=== p={pd} ===")
        for name, r in entries.items():
            print(f"  {name:20s} Gamma*={r['gamma_mean']:.3f} gap={r['min_gap_mean']:.1f}m "
                  f"TTC={r['min_ttc_mean']:.1f}s jerk={r['jerk_mean']:.3f} "
                  f"E={r['energy_mean']:.2f} headway={r['effective_headway_s']:.3f}s")

    with open("results/baseline_comparison/full_metrics.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\nSaved -> results/baseline_comparison/full_metrics.json")
