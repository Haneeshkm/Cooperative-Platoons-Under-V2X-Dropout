#!/usr/bin/env python3
"""
Reproduce Figure "Per-vehicle steady-state velocity amplification" (additive-feedforward
baseline, perfect V2X vs 40% dropout, mean +/- std across the five canonical evaluation
seeds -- not a single illustrative seed, to avoid the seed-cherry-picking risk this
project's own results have repeatedly shown matters for this baseline).

Usage:
    python scripts/make_fig_amplification.py
"""
from __future__ import annotations
import argparse

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from cacc.controllers import CACC
from cacc.evaluation import run_rollout, CANONICAL_EVAL_SEEDS


def gamma_i_profile(p_drop, seed, omega=0.45, n=8):
    r = run_rollout(lambda nn: [CACC() for _ in range(nn)], seed, n_followers=n,
                     p_drop=p_drop, omega=omega)
    vel = r.log["vel"]
    dt = 0.1
    T_p = 2 * np.pi / omega
    window = int(np.ceil(3 * T_p / dt))
    k0 = max(0, vel.shape[0] - window)
    seg = vel[k0:]
    ptp = seg.max(axis=0) - seg.min(axis=0)
    return ptp / max(ptp[0], 1e-6)


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--out", default="fig_amplification.pdf")
    args = p.parse_args()

    seeds = CANONICAL_EVAL_SEEDS
    perfect_all = np.array([gamma_i_profile(0.0, s) for s in seeds])
    dropout_all = np.array([gamma_i_profile(0.4, s) for s in seeds])
    perfect_mean = perfect_all.mean(axis=0)
    dropout_mean = dropout_all.mean(axis=0)
    dropout_std = dropout_all.std(axis=0)

    print("perfect V2X, mean across seeds:", np.round(perfect_mean, 3))
    print("40% dropout, mean across seeds:", np.round(dropout_mean, 3))
    print("40% dropout, std across seeds: ", np.round(dropout_std, 3))
    print("peak dropout Gamma* (mean):", dropout_mean[1:].max())

    fig, ax = plt.subplots(figsize=(5.2, 3.8))
    idx = np.arange(len(perfect_mean))
    ax.plot(idx, perfect_mean, marker="o", color="#0072B2", label="perfect V2X ($p{=}0$)")
    ax.errorbar(idx, dropout_mean, yerr=dropout_std, marker="s", color="#D55E00",
                label=r"$40\%$ dropout (mean$\pm$std, 5 seeds)", capsize=3)
    ax.axhline(1.0, color="k", ls="--", lw=1, label="string-stability limit")
    ax.set_xlabel("vehicle index (0 = lead)")
    ax.set_ylabel(r"$\Gamma_i$ (peak-to-peak velocity / lead)")
    ax.legend(loc="upper right", fontsize=8.5, framealpha=0.9)
    ax.set_xticks(idx)
    plt.tight_layout()
    plt.savefig(args.out)
    print(f"Saved -> {args.out}")


if __name__ == "__main__":
    main()
