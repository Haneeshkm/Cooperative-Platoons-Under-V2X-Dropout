import sys, os, time
sys.path.insert(0, '.')
import numpy as np
import torch
torch.set_num_threads(1)

from cacc.marl_env import PlatoonMARLEnv, MARLConfig
from cacc.maddpg import MADDPG, ReplayBuffer
from cacc import scenarios, V2XParams

N_EPISODES = 120
TIME_BUDGET_S = 180
MODEL_DIR = "models_extended_freq"
CKPT_DIR = "checkpoints_extended_freq"
os.makedirs(MODEL_DIR, exist_ok=True)
os.makedirs(CKPT_DIR, exist_ok=True)

# Extended disturbance period range: [10, 50]s -> omega in [0.126, 0.628] rad/s,
# reaching down toward the omega=0.10-0.20 band where seed 10 failed outright.
# Episode horizon extended from 40s to 110s to comfortably contain >2 full cycles
# even at the longest (50s) trained period.
EXTENDED_PERIOD_RANGE = (10.0, 50.0)
EXTENDED_T = 110.0


def build(seed, n_followers=6):
    np.random.seed(seed)
    torch.manual_seed(seed)
    mcfg = MARLConfig(n_followers=n_followers, penetration=1.0, T=EXTENDED_T,
                       randomize_disturbance=True,
                       disturbance_period_range=EXTENDED_PERIOD_RANGE)
    env = PlatoonMARLEnv(mcfg, scenarios.highway_cruise(),
                          V2XParams(mode="bernoulli", p_drop=0.3, delay_steps=1),
                          rng=np.random.default_rng(seed), randomize_dropout=True)
    algo = MADDPG(env.n_agents, hide_raw_comm=False)
    buf = ReplayBuffer(200_000, env.n_agents)
    return env, algo, buf


def run_one_episode(env, algo, buf, ep, seed, n_episodes):
    obs = env.reset(seed=seed * 10_000 + ep)
    arr = np.stack([obs[ai] for ai in env.agent_idx])
    noise = max(0.05, 0.25 - 0.20 * (ep / n_episodes))
    ep_return = 0.0
    while True:
        acts = algo.act(arr, noise=noise)
        nobs, rew, dones, info = env.step({ai: acts[j] for j, ai in enumerate(env.agent_idx)})
        narr = np.stack([nobs[ai] for ai in env.agent_idx])
        buf.push(arr, acts.astype(np.float32),
                  np.array([rew[ai] for ai in env.agent_idx], np.float32), narr,
                  np.array([float(dones[ai]) for ai in env.agent_idx], np.float32))
        algo.update(buf, batch=256)
        arr = narr
        ep_return += sum(rew.values()) / len(rew)
        if any(dones.values()):
            return ep_return


def save_ckpt(path, algo, buf, ep_idx, ep_returns, total_time):
    torch.save({
        "actor_state": algo.actor.state_dict(), "actor_t_state": algo.actor_t.state_dict(),
        "critic_state": algo.critic.state_dict(), "critic_t_state": algo.critic_t.state_dict(),
        "opt_a_state": algo.opt_a.state_dict(), "opt_c_state": algo.opt_c.state_dict(),
        "total_it": algo.total_it, "buf": buf.buf, "buf_pos": buf.pos,
        "ep_idx": ep_idx, "ep_returns": ep_returns, "total_time": total_time,
        "np_random_state": np.random.get_state(), "torch_random_state": torch.get_rng_state(),
    }, path)


def load_ckpt(path, algo, buf):
    ck = torch.load(path, weights_only=False)
    algo.actor.load_state_dict(ck["actor_state"]); algo.actor_t.load_state_dict(ck["actor_t_state"])
    algo.critic.load_state_dict(ck["critic_state"]); algo.critic_t.load_state_dict(ck["critic_t_state"])
    algo.opt_a.load_state_dict(ck["opt_a_state"]); algo.opt_c.load_state_dict(ck["opt_c_state"])
    algo.total_it = ck["total_it"]; buf.buf = ck["buf"]; buf.pos = ck["buf_pos"]
    np.random.set_state(ck["np_random_state"]); torch.set_rng_state(ck["torch_random_state"])
    return ck["ep_idx"], ck["ep_returns"], ck["total_time"]


if __name__ == "__main__":
    seed = int(sys.argv[1])
    final_path = f"{MODEL_DIR}/full_gate_seed{seed}.pt"
    ckpt_path = f"{CKPT_DIR}/seed{seed}.pt"
    if os.path.exists(final_path):
        print(f"[already complete] {final_path}"); sys.exit(0)

    env, algo, buf = build(seed)
    if os.path.exists(ckpt_path):
        ep, ep_returns, total_time = load_ckpt(ckpt_path, algo, buf)
        print(f"[resume] seed={seed} from episode {ep}/{N_EPISODES}")
    else:
        ep, ep_returns, total_time = 0, [], 0.0
        print(f"[start] seed={seed} (extended period range {EXTENDED_PERIOD_RANGE}, T={EXTENDED_T}s)")

    t0 = time.time()
    while ep < N_EPISODES and (time.time() - t0) < TIME_BUDGET_S:
        ep_returns.append(run_one_episode(env, algo, buf, ep, seed, N_EPISODES))
        ep += 1
    elapsed = time.time() - t0
    total_time += elapsed

    if ep >= N_EPISODES:
        torch.save({"actor_state": algo.actor.state_dict(), "hide_raw_comm": False,
                    "ep_returns": ep_returns, "train_time_s": total_time}, final_path)
        if os.path.exists(ckpt_path):
            os.remove(ckpt_path)
        print(f"[COMPLETE] seed={seed}: {ep} episodes, {total_time:.1f}s, "
              f"return last10={np.mean(ep_returns[-10:]):.1f} -> {final_path}")
    else:
        save_ckpt(ckpt_path, algo, buf, ep, ep_returns, total_time)
        print(f"[checkpoint] seed={seed}: {ep}/{N_EPISODES} ({elapsed:.1f}s this run, "
              f"{total_time:.1f}s total, recent return={np.mean(ep_returns[-5:]):.1f})")
