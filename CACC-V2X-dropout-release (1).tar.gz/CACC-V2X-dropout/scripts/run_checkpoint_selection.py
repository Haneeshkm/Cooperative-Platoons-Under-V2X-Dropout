#!/usr/bin/env python3
"""
Reproduce the checkpoint-selection diagnostic (Section "Learned Controller",
paragraph on seed 14 / the failed training run; see also CORRECTIONS.md).

Evaluates every periodic snapshot of one training run (produced by
scripts/train.py --snapshot-every N) on both a cheap held-out probe and the
full canonical protocol, to check whether a held-out-Gamma*-based checkpoint
selection would have rescued a training run that fails at its final episode.

For the one training seed in this study that fails (seed 14 in the paper),
the answer is no: no checkpoint after the initial, functionally-inert one (a
degenerate policy that trivially attains Gamma* by holding constant speed) is
string stable. This script also demonstrates why held-out selection needs a
functionality guard: naive selection-by-lowest-Gamma* picks that inert first
checkpoint, which is a red flag (an undertrained policy doing nothing looks
"perfect" by this metric alone), not a good sign.

Usage:
    python scripts/train.py --seed 14 --episodes 150 --snapshot-every 20   # (repeat to completion)
    python scripts/run_checkpoint_selection.py --seed 14 --variant full_gate
"""
from __future__ import annotations
import argparse
import glob
import json
import os
import re

import torch

from cacc.evaluation import evaluate, make_rl_controllers, load_actor

HELD_OUT_SEEDS = [200, 201]   # disjoint from the canonical evaluation seeds 5-9
CANONICAL_SEEDS = list(range(5, 10))


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--seed", type=int, required=True)
    p.add_argument("--variant", default="full_gate")
    p.add_argument("--snapshot-dir", default="snapshots")
    p.add_argument("--p-drop", type=float, default=0.3)
    p.add_argument("--out-dir", default="results/checkpoint_selection")
    args = p.parse_args()

    torch.set_num_threads(1)
    paths = sorted(
        glob.glob(f"{args.snapshot_dir}/{args.variant}_seed{args.seed}_ep*.pt"),
        key=lambda p_: int(re.search(r"_ep(\d+)\.pt", p_).group(1)))
    if not paths:
        raise SystemExit(f"No snapshots found under {args.snapshot_dir}/ for "
                          f"{args.variant}_seed{args.seed}. Train with "
                          f"--snapshot-every first (see module docstring).")

    rows = []
    for path in paths:
        ep = int(re.search(r"_ep(\d+)\.pt", path).group(1))
        actor = load_actor(path)
        held = evaluate(lambda n: make_rl_controllers(actor, n), seeds=HELD_OUT_SEEDS,
                         T=60.0, p_drop=args.p_drop)
        canon = evaluate(lambda n: make_rl_controllers(actor, n), seeds=CANONICAL_SEEDS,
                          T=120.0, p_drop=args.p_drop)
        rows.append({"episode": ep, "held_out_gamma": held.gamma_mean,
                      "canonical_gamma": canon.gamma_mean, "canonical_f_stable": canon.f_stable})
        print(f"ep={ep:4d}  held-out(2 seeds, T=60s) Gamma*={held.gamma_mean:.3f}  |  "
              f"canonical(5 seeds, T=120s) Gamma*={canon.gamma_mean:.3f} "
              f"f_stable={canon.f_stable:.2f}")

    best = min(rows, key=lambda r: r["held_out_gamma"])
    final = rows[-1]
    print(f"\nBest by naive held-out selection: episode {best['episode']} "
          f"(held-out Gamma*={best['held_out_gamma']:.3f}) "
          f"-> canonical Gamma*={best['canonical_gamma']:.3f}, "
          f"f_stable={best['canonical_f_stable']:.2f}")
    if best["canonical_gamma"] < 0.05:
        print("  WARNING: this checkpoint's near-zero Gamma* is consistent with a "
              "functionally-inert policy (holding constant speed), not real control "
              "competence -- naive held-out-Gamma* selection needs a functionality "
              "guard (e.g. a minimum training-return threshold) alongside it.")
    print(f"Final (no selection): episode {final['episode']} "
          f"-> canonical Gamma*={final['canonical_gamma']:.3f}, "
          f"f_stable={final['canonical_f_stable']:.2f}")
    n_stable_after_first = sum(1 for r in rows[1:] if r["canonical_f_stable"] == 1.0)
    print(f"Checkpoints after the first that are string-stable: "
          f"{n_stable_after_first}/{len(rows)-1}")

    os.makedirs(args.out_dir, exist_ok=True)
    out_path = f"{args.out_dir}/{args.variant}_seed{args.seed}.json"
    with open(out_path, "w") as f:
        json.dump({"rows": rows, "best": best, "final": final}, f, indent=2)
    print(f"Saved -> {out_path}")


if __name__ == "__main__":
    main()
