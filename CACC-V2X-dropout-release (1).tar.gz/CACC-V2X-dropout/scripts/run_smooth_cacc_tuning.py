#!/usr/bin/env python3
"""
Reproduce the SmoothCACC hyperparameter sweep (Section "Do Standard
Dropout-Handling Heuristics Help?" -- "Jointly smoothing headway and
feedforward"), finding the best-case classical continuous scheduler at each
dropout rate before it is compared against the learned controller.

Usage:
    python scripts/run_smooth_cacc_tuning.py
"""
from __future__ import annotations
import argparse
import itertools
import json
import os

from cacc.controllers import SmoothCACC
from cacc.evaluation import evaluate

DEFAULT_TAU_R_GRID = [0.15, 0.3, 0.5, 0.75, 1.0, 1.5, 2.0]
DEFAULT_KFF_GRID = [0.6, 0.8, 1.0, 1.2, 1.5]


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--p-drops", type=float, nargs="+", default=[0.3, 0.6])
    p.add_argument("--tau-r-grid", type=float, nargs="+", default=DEFAULT_TAU_R_GRID)
    p.add_argument("--kff-grid", type=float, nargs="+", default=DEFAULT_KFF_GRID)
    p.add_argument("--out", default="results/smooth_cacc_tuning/sweep.json")
    args = p.parse_args()

    results: dict = {}
    for pd in args.p_drops:
        rows = []
        for tau_r, kff in itertools.product(args.tau_r_grid, args.kff_grid):
            r = evaluate(lambda n: [SmoothCACC(tau_r=tau_r, kff=kff) for _ in range(n)],
                         p_drop=pd)
            rows.append({"tau_r": tau_r, "kff": kff, **r.as_dict()})
        rows.sort(key=lambda r: (-r["f_stable"], r["gamma_mean"]))
        results[f"p={pd}"] = rows
        best = rows[0]
        print(f"p={pd}: best config tau_r={best['tau_r']:.2f} kff={best['kff']:.2f} "
              f"-> Gamma*={best['gamma_mean']:.3f}+/-{best['gamma_std']:.3f} "
              f"f_stable={best['f_stable']:.2f}")

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w") as f:
        json.dump(results, f, indent=2)
    print(f"Saved full grid -> {args.out}")


if __name__ == "__main__":
    main()
