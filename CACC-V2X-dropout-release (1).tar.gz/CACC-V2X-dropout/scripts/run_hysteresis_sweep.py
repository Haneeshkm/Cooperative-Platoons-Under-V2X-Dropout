#!/usr/bin/env python3
"""
Reproduce the dwell-time hysteresis sweep (Table "Dwell-time hysteresis sweep",
Section "Do non-learned continuous remedies fix it?").

Sweeps both the literature-typical asymmetric design (fast degrade, slow recover:
K_degrade=1, K_recover swept) and a symmetric hysteresis band (K_degrade=K_recover=K),
at p=0.3, plus the symmetric design at p=0.6 to test whether stability found at
moderate loss survives severe loss.

Usage:
    python scripts/run_hysteresis_sweep.py
"""
from __future__ import annotations
import argparse
import json
import os

from cacc.controllers import DwellHysteresisCACC
from cacc.evaluation import evaluate


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--out", default="results/hysteresis_sweep/sweep.json")
    args = p.parse_args()

    results = {"asymmetric_p03": {}, "symmetric_p03": {}, "symmetric_p06": {}}

    print("=== Asymmetric (K_degrade=1, fast-degrade/slow-recover), p=0.3 ===")
    for K_recover in (1, 3, 5, 10):
        r = evaluate(lambda n: [DwellHysteresisCACC(K_degrade=1, K_recover=K_recover)
                                  for _ in range(n)], p_drop=0.3)
        results["asymmetric_p03"][K_recover] = r.as_dict()
        print(f"K_recover={K_recover:2d}: Gamma*={r.gamma_mean:.3f}+/-{r.gamma_std:.3f} "
              f"f_stable={r.f_stable:.2f} jerk={r.jerk_mean:.3f}")

    print("\n=== Symmetric (K_degrade=K_recover=K), p=0.3 ===")
    for K in (1, 3, 5, 10):
        r = evaluate(lambda n: [DwellHysteresisCACC(K_degrade=K, K_recover=K)
                                  for _ in range(n)], p_drop=0.3)
        results["symmetric_p03"][K] = r.as_dict()
        print(f"K={K:2d}: Gamma*={r.gamma_mean:.3f}+/-{r.gamma_std:.3f} "
              f"f_stable={r.f_stable:.2f} jerk={r.jerk_mean:.3f}")

    print("\n=== Symmetric, p=0.6 ===")
    for K in (3, 5, 10, 15):
        r = evaluate(lambda n: [DwellHysteresisCACC(K_degrade=K, K_recover=K)
                                  for _ in range(n)], p_drop=0.6)
        results["symmetric_p06"][K] = r.as_dict()
        print(f"K={K:2d}: Gamma*={r.gamma_mean:.3f}+/-{r.gamma_std:.3f} "
              f"f_stable={r.f_stable:.2f} jerk={r.jerk_mean:.3f}")

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved -> {args.out}")


if __name__ == "__main__":
    main()
