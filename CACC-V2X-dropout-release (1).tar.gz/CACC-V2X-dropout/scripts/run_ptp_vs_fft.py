import sys, json
sys.path.insert(0, '.')
import numpy as np
import torch
torch.set_num_threads(1)

from cacc.controllers import CACC, SmoothCACC, RLPolicy
from cacc.platoon import Platoon, PlatoonConfig
from cacc.v2x import V2XParams
from cacc.idm import sample_idm_population
from cacc.evaluation import load_actor, make_rl_controllers
from cacc import scenarios

DT = 0.1
SEEDS = list(range(5, 10))
# Deliberately uses max(120s, 9 disturbance periods) rather than the fixed T=120s used
# in the main benchmark tables: this analysis needs a long, robust settling window at
# every tested frequency (it is examining steady-state behaviour itself, not comparing
# a single headline number across controllers at one fixed omega), so a period-scaled
# floor is the right choice here and is deliberately NOT the same protocol as
# run_frequency_sweep.py (see that script's own history in CORRECTIONS.md for a case
# where a period-scaled horizon WAS a bug, because it was inconsistent with a shared
# benchmark point elsewhere -- that failure mode does not apply to this script, since
# every result here is internally self-consistent across the frequencies it tests).


def decompose(make_controllers, omega, p_drop=0.3, n_followers=8, seeds=SEEDS):
    T_p = 2 * np.pi / omega
    T = max(120.0, 9 * T_p)
    ptp_gammas, fft_gammas, toggle_rates, fallback_fracs = [], [], [], []
    for s in seeds:
        rng = np.random.default_rng(s)
        lead = scenarios.highway_cruise(v=25.0, amp=3.0, period=T_p)
        cfg = PlatoonConfig(n_followers=n_followers, dt=DT, T=T, init_gap=20.0, init_speed=25.0)
        controllers = make_controllers(n_followers)
        pl = Platoon(cfg, lead, ['controlled'] * n_followers, controllers,
                     human_params=sample_idm_population(n_followers, rng),
                     v2x_params=V2XParams(mode='bernoulli', p_drop=p_drop, delay_steps=1), rng=rng)
        log = pl.run()
        vel = log['vel']
        window = int(np.ceil(3 * T_p / DT))
        k0 = max(0, vel.shape[0] - window)
        seg = vel[k0:]
        t = np.arange(seg.shape[0]) * DT

        ptp = seg.max(axis=0) - seg.min(axis=0)
        ptp_gammas.append(float(np.max(ptp[1:] / max(ptp[0], 1e-6))))

        amps = []
        for i in range(seg.shape[1]):
            c = np.sum(seg[:, i] * np.cos(omega * t)) * 2 / len(t)
            si = np.sum(seg[:, i] * np.sin(omega * t)) * 2 / len(t)
            amps.append(np.hypot(c, si))
        amps = np.array(amps)
        fft_gammas.append(float(np.max(amps[1:] / max(amps[0], 1e-9))))

        # dropout process stats (same window), from the logged v2x_received mask --
        # a property of the channel process itself, reported for context.
        recv = log['v2x_received'][k0:]
        toggles = np.abs(np.diff(recv.astype(int), axis=0)).sum(axis=0)
        toggle_rates.append(float(np.mean(toggles) / (seg.shape[0] * DT) * 60.0))  # toggles/min
        fallback_fracs.append(float(1.0 - recv.mean()))

    return {
        "ptp_gamma": float(np.mean(ptp_gammas)),
        "fft_gamma": float(np.mean(fft_gammas)),
        "gap": float(np.mean(ptp_gammas) - np.mean(fft_gammas)),
        "toggle_rate_per_min": float(np.mean(toggle_rates)),
        "fallback_frac": float(np.mean(fallback_fracs)),
    }


if __name__ == "__main__":
    omegas = [0.15, 0.30, 0.45, 0.80]
    results = {}

    actors = {s: load_actor(f"models/full_gate_seed{s}.pt") for s in (10, 11, 12, 13)}

    for om in omegas:
        row = {}
        row["naive_CACC"] = decompose(lambda n: [CACC() for _ in range(n)], om)
        row["smooth_CACC_tuned"] = decompose(
            lambda n: [SmoothCACC(tau_r=2.0, kff=0.8) for _ in range(n)], om)
        rl_ptp, rl_fft, rl_gap = [], [], []
        for s, actor in actors.items():
            d = decompose(lambda n, a=actor: make_rl_controllers(a, n), om)
            rl_ptp.append(d["ptp_gamma"]); rl_fft.append(d["fft_gamma"]); rl_gap.append(d["gap"])
        row["RL_mean_4seeds"] = {"ptp_gamma": float(np.mean(rl_ptp)),
                                  "fft_gamma": float(np.mean(rl_fft)),
                                  "gap": float(np.mean(rl_gap))}
        results[f"omega={om}"] = row
        print(f"\n=== omega={om} ===")
        for name, r in row.items():
            extra = f" toggle={r.get('toggle_rate_per_min','-'):.1f}/min fallback={r.get('fallback_frac','-'):.2f}" if 'toggle_rate_per_min' in r else ""
            print(f"  {name:20s} ptp={r['ptp_gamma']:.3f} fft={r['fft_gamma']:.3f} gap={r['gap']:.3f}{extra}")

    with open("results/frequency_sweep/ptp_vs_fft_decomposition.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\nSaved -> results/frequency_sweep/ptp_vs_fft_decomposition.json")
