#!/usr/bin/env python3
"""
Reproduce Table "Learned controller versus classical baselines" (Section
"Learned Controller: String-Stable CACC under Dropout").

Compares naive (binary-switch) CACC, the best-tuned SmoothCACC classical
scheduler (see run_smooth_cacc_tuning.py), and the learned controller across
all successful training seeds, at both dropout rates.

Usage:
    python scripts/run_baseline_comparison.py
"""
from __future__ import annotations
import argparse
import json
import os

import torch

from cacc.controllers import CACC, SmoothCACC
from cacc.evaluation import evaluate, make_rl_controllers, load_actor

# Best-tuned configurations found by run_smooth_cacc_tuning.py at p=0.3 / p=0.6
# respectively; override with --tau-r/--kff if you re-ran the sweep and got a
# different optimum.
TUNED_SMOOTH = {0.3: dict(tau_r=2.0, kff=0.8), 0.6: dict(tau_r=2.0, kff=0.6)}


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--seeds", type=int, nargs="+", default=[10, 11, 12, 13, 14])
    p.add_argument("--model-dir", default="models")
    p.add_argument("--variant", default="full_gate")
    p.add_argument("--p-drops", type=float, nargs="+", default=[0.3, 0.6])
    p.add_argument("--out", default="results/baseline_comparison/comparison.json")
    args = p.parse_args()

    torch.set_num_threads(1)
    results: dict = {}
    for pd in args.p_drops:
        entries = {}
        entries["naive_CACC"] = evaluate(lambda n: [CACC() for _ in range(n)],
                                          p_drop=pd).as_dict()
        smooth_cfg = TUNED_SMOOTH.get(pd, dict(tau_r=2.0, kff=0.8))
        entries["smooth_CACC_tuned"] = evaluate(
            lambda n: [SmoothCACC(**smooth_cfg) for _ in range(n)], p_drop=pd).as_dict()
        for seed in args.seeds:
            actor = load_actor(f"{args.model_dir}/{args.variant}_seed{seed}.pt")
            entries[f"RL_seed{seed}"] = evaluate(
                lambda n, a=actor: make_rl_controllers(a, n), p_drop=pd).as_dict()
        results[f"p={pd}"] = entries
        print(f"\n=== p={pd} ===")
        for name, r in entries.items():
            print(f"  {name:20s} Gamma*={r['gamma_mean']:.3f}+/-{r['gamma_std']:.3f} "
                  f"f_stable={r['f_stable']:.2f} jerk={r['jerk_mean']:.3f}")

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved -> {args.out}")


if __name__ == "__main__":
    main()
