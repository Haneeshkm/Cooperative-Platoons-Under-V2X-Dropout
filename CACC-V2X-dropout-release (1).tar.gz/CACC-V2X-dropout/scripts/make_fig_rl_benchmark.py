#!/usr/bin/env python3
"""
Reproduce Figure "Learned controller versus classical baselines" (two panels: (a)
Gamma* vs. V2X dropout probability, (b) Gamma* vs. disturbance frequency, both per
training seed).

Panel (b) reuses the per-seed frequency sweep already produced by
run_frequency_sweep.py (run that first for each of the four successful seeds). Panel
(a) is a new continuous dropout-probability sweep this script runs directly, since the
main results only evaluate the two headline points p=0.3 and p=0.6.

Usage:
    python scripts/run_frequency_sweep.py --model models/full_gate_seed10.pt --out results/frequency_sweep/sweep_seed10.json
    python scripts/run_frequency_sweep.py --model models/full_gate_seed11.pt --out results/frequency_sweep/sweep_seed11.json
    python scripts/run_frequency_sweep.py --model models/full_gate_seed12.pt --out results/frequency_sweep/sweep_seed12.json
    python scripts/run_frequency_sweep.py --model models/full_gate_seed13.pt --out results/frequency_sweep/sweep_seed13.json
    python scripts/make_fig_rl_benchmark.py
"""
from __future__ import annotations
import argparse
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import torch

from cacc.controllers import CACC
from cacc.evaluation import evaluate, make_rl_controllers, load_actor

SEEDS = [10, 11, 12, 13]
SEED_LABELS = {10: "seed A", 11: "seed B", 12: "seed C", 13: "seed D"}
COLORS = {"seed A": "#0072B2", "seed B": "#E69F00", "seed C": "#009E73", "seed D": "#D55E00"}
DROPOUT_PS = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6]
OMEGAS = [0.10, 0.20, 0.30, 0.45, 0.60, 0.80, 1.00, 1.30, 1.60]


def run_dropout_sweep(model_dir="models", variant="full_gate",
                        out="results/frequency_sweep/dropout_sweep_all.json"):
    results = {}
    for seed in SEEDS:
        actor = load_actor(f"{model_dir}/{variant}_seed{seed}.pt")
        rows = []
        for p in DROPOUT_PS:
            r = evaluate(lambda n: make_rl_controllers(actor, n), p_drop=p)
            rows.append({"p": p, "gamma": r.gamma_mean, "f_stable": r.f_stable})
            print(f"seed={seed} p={p}: Gamma*={r.gamma_mean:.3f} f_stable={r.f_stable:.2f}")
        results[seed] = rows

    naive = []
    for p in DROPOUT_PS:
        r = evaluate(lambda n: [CACC() for _ in range(n)], p_drop=p)
        naive.append({"p": p, "gamma": r.gamma_mean, "f_stable": r.f_stable})
        print(f"naive p={p}: Gamma*={r.gamma_mean:.3f} f_stable={r.f_stable:.2f}")
    results["naive"] = naive

    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w") as f:
        json.dump(results, f, indent=2)
    print(f"Saved -> {out}")
    return results


def make_figure(dropout_json, freq_json_template, out_pdf="fig_rl_benchmark.pdf"):
    dsweep = json.load(open(dropout_json))

    fig, axes = plt.subplots(1, 2, figsize=(9.2, 3.6))
    for seed in SEEDS:
        rows = dsweep[str(seed)]
        axes[0].plot([r["p"] for r in rows], [r["gamma"] for r in rows], marker="o",
                     color=COLORS[SEED_LABELS[seed]], label=f"{SEED_LABELS[seed]} (RL)")
    axes[0].plot([r["p"] for r in dsweep["naive"]], [r["gamma"] for r in dsweep["naive"]],
                 marker="x", color="k", ls="--", label="naive CACC")
    axes[0].axhline(1.0, color="grey", ls=":", lw=1)
    axes[0].set_xlabel(r"V2X dropout probability $p$")
    axes[0].set_ylabel(r"$\Gamma^\star$")
    axes[0].set_title("(a) vs. dropout probability")
    axes[0].legend(fontsize=7, loc="center left", bbox_to_anchor=(1.02, 0.5))

    for seed in SEEDS:
        path = freq_json_template.format(seed=seed)
        dd = json.load(open(path))
        gamma = [r["gamma_mean"] for r in dd["RL"]]
        axes[1].plot(OMEGAS, gamma, marker="o", color=COLORS[SEED_LABELS[seed]],
                     label=SEED_LABELS[seed])
    axes[1].axhline(1.0, color="grey", ls=":", lw=1)
    axes[1].set_xlabel(r"$\omega$ [rad/s]")
    axes[1].set_ylabel(r"$\Gamma^\star$")
    axes[1].set_title("(b) vs. disturbance frequency")

    plt.tight_layout()
    plt.savefig(out_pdf, bbox_inches="tight")
    print(f"Saved -> {out_pdf}")


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--model-dir", default="models")
    p.add_argument("--variant", default="full_gate")
    p.add_argument("--dropout-out", default="results/frequency_sweep/dropout_sweep_all.json")
    p.add_argument("--freq-template",
                    default="results/frequency_sweep/sweep_seed{seed}.json")
    p.add_argument("--fig-out", default="fig_rl_benchmark.pdf")
    args = p.parse_args()

    torch.set_num_threads(1)
    run_dropout_sweep(args.model_dir, args.variant, args.dropout_out)
    make_figure(args.dropout_out, args.freq_template, args.fig_out)


if __name__ == "__main__":
    main()
