#!/usr/bin/env python3
"""
Reproduce the Gilbert-Elliott (bursty) channel evaluation (Section "Robustness to
penetration and channel model").

IMPORTANT -- parameter correction: an earlier internal version of this script used
p_gb=0.05/p_bg=0.30/eps_g=0.02/eps_b=0.80 for the "default" severity, believing it was
mean-matched to the Bernoulli p=0.3 comparison. Independent re-verification (both
analytically, pi_bad*eps_b+(1-pi_bad)*eps_g with pi_bad=p_gb/(p_gb+p_bg), and
empirically over 3e5 simulated steps) found this configuration's TRUE stationary mean
loss is 0.131, not 0.30 -- a genuine parameterization bug, not a documentation gap; see
CORRECTIONS.md. The two configurations below were solved for and independently
re-verified to both equal 0.30 mean loss while differing in burstiness (mean bad-state
dwell 0.33s vs 0.67s) by construction. run_verify_ge_params() reproduces that check
directly from this file's own parameters on every run, so it cannot silently drift again.

Usage:
    python scripts/run_ge_dropout_sweep.py
    python scripts/run_ge_dropout_sweep.py --verify-only   # just print the mean-loss check
"""
from __future__ import annotations
import argparse
import json
import os

import numpy as np
import torch

from cacc.evaluation import evaluate, make_rl_controllers, load_actor
from cacc.v2x import V2XParams, V2XChannel

TRAIN_SEEDS = [10, 11, 12, 13, 14]

# Corrected, independently re-verified parameters (Table "Gilbert-Elliott channel
# parameters" in the manuscript). Both configurations share the Bernoulli channel's
# stationary mean loss (bar-p = 0.30) and differ only in burstiness.
GE_CONFIGS = {
    "milder_burst": dict(p_gb=0.168, p_bg=0.30, drop_good=0.02, drop_bad=0.80),
    "severe_burst": dict(p_gb=0.065, p_bg=0.15, drop_good=0.02, drop_bad=0.95),
}


def analytic_mean_loss(p_gb, p_bg, drop_good, drop_bad):
    pi_bad = p_gb / (p_gb + p_bg)
    return pi_bad * drop_bad + (1 - pi_bad) * drop_good


def empirical_mean_loss(v2x_params, n_steps=300_000, seed=0):
    rng = np.random.default_rng(seed)
    ch = V2XChannel(v2x_params, rng)
    drops = sum(int(ch._is_dropped()) for _ in range(n_steps))
    return drops / n_steps


def run_verify_ge_params():
    print("=== Verifying GE parameters are genuinely mean-matched to p=0.30 ===")
    for name, cfg in GE_CONFIGS.items():
        analytic = analytic_mean_loss(**cfg)
        v2xp = V2XParams(mode="gilbert_elliott", delay_steps=1, **cfg)
        empirical = empirical_mean_loss(v2xp)
        mean_bad_dwell = (1.0 / cfg["p_bg"]) * 0.1  # steps -> seconds
        print(f"{name}: analytic_mean={analytic:.3f} empirical_mean={empirical:.3f} "
              f"mean_bad_dwell={mean_bad_dwell:.2f}s")
        assert abs(analytic - 0.30) < 0.005, f"{name} analytic mean loss drifted from 0.30!"
        assert abs(empirical - 0.30) < 0.02, f"{name} empirical mean loss drifted from 0.30!"
    print("OK: both configurations verified mean-matched to p=0.30.\n")


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--seeds", type=int, nargs="+", default=TRAIN_SEEDS)
    p.add_argument("--model-dir", default="models")
    p.add_argument("--variant", default="full_gate")
    p.add_argument("--verify-only", action="store_true")
    p.add_argument("--out", default="results/ge_dropout_sweep/sweep.json")
    args = p.parse_args()

    torch.set_num_threads(1)
    run_verify_ge_params()
    if args.verify_only:
        return

    results = {}
    for name, cfg in GE_CONFIGS.items():
        results[name] = {}
        v2xp = V2XParams(mode="gilbert_elliott", delay_steps=1, **cfg)
        for seed in args.seeds:
            actor = load_actor(f"{args.model_dir}/{args.variant}_seed{seed}.pt")
            r = evaluate(lambda n: make_rl_controllers(actor, n), v2x_params=v2xp)
            results[name][str(seed)] = r.as_dict()
            print(f"{name} seed={seed}  Gamma*={r.gamma_mean:.3f}+/-{r.gamma_std:.3f} "
                  f"f_stable={r.f_stable:.2f}")

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved -> {args.out}")


if __name__ == "__main__":
    main()
