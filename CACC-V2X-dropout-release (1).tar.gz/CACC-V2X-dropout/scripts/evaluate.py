#!/usr/bin/env python3
"""
Evaluate one trained controller under the canonical protocol.

This is the general-purpose entry point; the specific reproduction scripts
(run_gate_ablation.py, run_frequency_sweep.py, etc.) call the same
cacc.evaluation functions this script uses, just with the sweep dimension
of interest varied. Use this script directly when you just want one number.

Examples:
    # canonical protocol, p=0.3, omega=0.45, 8 followers
    python scripts/evaluate.py --model models/full_gate_seed10.pt

    # p=0.6
    python scripts/evaluate.py --model models/full_gate_seed10.pt --p-drop 0.6

    # forced gate ablation
    python scripts/evaluate.py --model models/full_gate_seed10.pt --force-gate 0.0
    python scripts/evaluate.py --model models/full_gate_seed10.pt --force-gate 1.0

    # a different disturbance frequency or platoon length
    python scripts/evaluate.py --model models/full_gate_seed10.pt --omega 0.20
    python scripts/evaluate.py --model models/full_gate_seed10.pt --n-followers 14

    # mixed autonomy
    python scripts/evaluate.py --model models/full_gate_seed10.pt --penetration 0.5

    # bursty (Gilbert-Elliott) channel instead of i.i.d. Bernoulli
    python scripts/evaluate.py --model models/full_gate_seed10.pt --channel ge
"""
from __future__ import annotations
import argparse
import json

import torch

from cacc.evaluation import (evaluate, make_rl_controllers, load_actor,
                              forced_gate_actor_fn, CANONICAL_EVAL_SEEDS)
from cacc.controllers import RLPolicy
from cacc.marl_env import OBS_KEYS
from cacc.v2x import V2XParams

# Matches the "default" Gilbert-Elliott config in sweep_ge_dropout.py / the paper's
# Table tab:ctrl: long-run average drop probability ~0.13, but bursty (extended
# outages while in the "bad" state).
GE_DEFAULT = dict(p_gb=0.05, p_bg=0.30, drop_good=0.02, drop_bad=0.80)


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--model", required=True, help="Path to a trained model .pt file.")
    p.add_argument("--force-gate", type=float, default=None,
                    help="Pin the gate to this constant (0.0 or 1.0) instead of "
                         "using the trained adaptive gate.")
    p.add_argument("--p-drop", type=float, default=0.3)
    p.add_argument("--omega", type=float, default=0.45, help="Disturbance frequency [rad/s].")
    p.add_argument("--n-followers", type=int, default=8)
    p.add_argument("--penetration", type=float, default=1.0,
                    help="Fraction of followers that are RL-controlled; the rest are IDM humans.")
    p.add_argument("--channel", choices=["bernoulli", "ge"], default="bernoulli")
    p.add_argument("--seeds", type=int, nargs="+", default=CANONICAL_EVAL_SEEDS)
    p.add_argument("--json", action="store_true", help="Print machine-readable JSON only.")
    args = p.parse_args()

    torch.set_num_threads(1)
    actor = load_actor(args.model)

    if args.force_gate is not None:
        controller_fn = lambda n: [RLPolicy(forced_gate_actor_fn(actor, args.force_gate),
                                             OBS_KEYS) for _ in range(n)]
    else:
        controller_fn = lambda n: make_rl_controllers(actor, n)

    if args.channel == "ge":
        v2x_params = V2XParams(mode="gilbert_elliott", delay_steps=1, **GE_DEFAULT)
    else:
        v2x_params = None  # evaluate() builds the default Bernoulli channel from p_drop

    result = evaluate(controller_fn, seeds=args.seeds, n_followers=args.n_followers,
                       p_drop=args.p_drop, omega=args.omega, penetration=args.penetration,
                       v2x_params=v2x_params)

    if args.json:
        print(json.dumps(result.as_dict(), indent=2))
    else:
        print(f"model:        {args.model}")
        if args.force_gate is not None:
            print(f"gate:         forced g={args.force_gate}")
        print(f"p_drop:       {args.p_drop}  (channel={args.channel})")
        print(f"omega:        {args.omega} rad/s")
        print(f"n_followers:  {args.n_followers}  penetration={args.penetration}")
        print(f"eval seeds:   {args.seeds}")
        print("-" * 40)
        print(f"Gamma*:       {result.gamma_mean:.3f} +/- {result.gamma_std:.3f}")
        print(f"f_stable:     {result.f_stable:.2f}")
        print(f"RMS jerk:     {result.jerk_mean:.3f} m/s^3")
        print(f"energy:       {result.energy_mean:.2f} kWh/100km")


if __name__ == "__main__":
    main()
