#!/usr/bin/env python3
"""
Reproduce Table "Isolating the destabilising mechanism" (Section "Closed-form string
stability and the mechanism of dropout-induced failure").

Uses the canonical, plant-inverting CACC controller (verified in tests/test_controllers_and_metrics.py
to satisfy G(s)=1/(1+hs) exactly under this project's actuator model -- see
cacc.controllers.PlantInvertingCACC's docstring for the closed-form derivation) in its
three degradation modes (switch / ff_drop_only / smooth), plus the paper's own
deliberately non-canonical additive-feedforward baseline for reference.

Also reproduces:
  - the window-length (M=2/3/5 disturbance cycles) sensitivity check quoted in the
    table caption, confirming the qualitative separation is not a windowing artefact;
  - the delay-sensitivity check (D in {0,1,2,4} steps at perfect reception) quoted in
    Methods, confirming the plant-inverting design degrades gracefully rather than
    losing its stability property once the simulator's actual 1-step delay is present.

Usage:
    python scripts/run_mechanism_ablation.py
"""
from __future__ import annotations
import argparse
import json
import os

import numpy as np

from cacc.controllers import PlantInvertingCACC, CACC
from cacc.evaluation import evaluate, run_rollout, CANONICAL_EVAL_SEEDS


def window_sensitivity(mode: str, M_values=(2, 3, 5), omega=0.45, p_drop=0.3,
                        seeds=CANONICAL_EVAL_SEEDS):
    """Recompute Gamma* with a shorter/longer last-M-cycles window than the
    canonical M=3, to check the qualitative conclusion is not a windowing artefact."""
    dt = 0.1
    T_p = 2 * np.pi / omega
    out = {}
    for M in M_values:
        gammas = []
        for s in seeds:
            r = run_rollout(lambda n: [PlantInvertingCACC(mode=mode) for _ in range(n)],
                             s, p_drop=p_drop, omega=omega)
            vel = r.log["vel"]
            window = int(np.ceil(M * T_p / dt))
            k0 = max(0, vel.shape[0] - window)
            seg = vel[k0:]
            ptp = seg.max(axis=0) - seg.min(axis=0)
            gammas.append(float(np.max(ptp[1:] / max(ptp[0], 1e-6))))
        out[M] = float(np.mean(gammas))
    return out


def delay_sensitivity(D_values=(0, 1, 2, 4), omega=0.45, seeds=CANONICAL_EVAL_SEEDS):
    """Plant-inverting controller at PERFECT reception (p_drop=0) across V2X
    transport delay D, isolating delay from dropout entirely."""
    from cacc.v2x import V2XParams
    out = {}
    for D in D_values:
        r = evaluate(lambda n: [PlantInvertingCACC(mode="switch") for _ in range(n)],
                     seeds=seeds, omega=omega, p_drop=0.0,
                     v2x_params=V2XParams(mode="bernoulli", p_drop=0.0, delay_steps=D))
        out[D] = r.gamma_mean
    return out


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--p-drop", type=float, default=0.3)
    p.add_argument("--out", default="results/mechanism_ablation/table1.json")
    args = p.parse_args()

    results = {}
    print("=== Table 1: isolating the destabilising mechanism ===")
    for mode in ("switch", "ff_drop_only", "smooth"):
        r = evaluate(lambda n: [PlantInvertingCACC(mode=mode) for _ in range(n)],
                     p_drop=args.p_drop)
        results[f"plant_inverting_{mode}"] = r.as_dict()
        print(f"Plant-inverting[{mode}]: Gamma*={r.gamma_mean:.3f}+/-{r.gamma_std:.3f} "
              f"f_stable={r.f_stable:.2f} jerk={r.jerk_mean:.3f}")

    r_additive = evaluate(lambda n: [CACC() for _ in range(n)], p_drop=args.p_drop)
    results["additive_feedforward_switch"] = r_additive.as_dict()
    print(f"Additive-feedforward[switch]: Gamma*={r_additive.gamma_mean:.3f}"
          f"+/-{r_additive.gamma_std:.3f} f_stable={r_additive.f_stable:.2f} "
          f"jerk={r_additive.jerk_mean:.3f}")

    print("\n=== Window-length (M) sensitivity, at p=%.1f ===" % args.p_drop)
    for mode in ("switch", "ff_drop_only"):
        ws = window_sensitivity(mode, p_drop=args.p_drop)
        results[f"window_sensitivity_{mode}"] = ws
        print(f"{mode}: " + "  ".join(f"M={m}:{g:.3f}" for m, g in ws.items()))

    print("\n=== Delay sensitivity (perfect reception, D in steps) ===")
    ds = delay_sensitivity()
    results["delay_sensitivity"] = ds
    print("  ".join(f"D={d}:{g:.3f}" for d, g in ds.items()))

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved -> {args.out}")


if __name__ == "__main__":
    main()
