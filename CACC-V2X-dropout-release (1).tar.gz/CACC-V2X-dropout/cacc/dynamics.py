"""
Longitudinal vehicle dynamics with first-order actuator lag and an
EV powertrain / energy model (with regenerative braking).

The model is a control-affine, string-stability-friendly formulation that is
consistent with the physics used in Haneesh & Jisha (2026):

    p_dot = v
    v_dot = a                         (a = realised longitudinal acceleration)
    a_dot = (a_cmd - a) / tau         (first-order actuator lag)

Resistive forces (aerodynamic drag, rolling resistance, road gradient) are
handled by the powertrain and therefore enter the *energy* accounting rather
than the kinematic acceleration. This is the standard convention for CACC /
string-stability studies and keeps the closed loop analytically tractable
while still letting us report physically grounded energy numbers.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np


@dataclass
class VehicleParams:
    # ---- physical parameters (Table 1 of the published paper) ----
    m: float = 1500.0          # mass [kg]
    A: float = 2.2             # frontal area [m^2]
    Cd: float = 0.30           # drag coefficient [-]
    Crr: float = 0.015         # rolling resistance coefficient [-]
    g: float = 9.81            # gravity [m/s^2]
    rho: float = 1.225         # air density [kg/m^3]
    v_max: float = 35.0        # max speed [m/s]
    tau: float = 0.3           # actuator time constant [s]
    a_min: float = -6.0        # min (braking) accel command [m/s^2]
    a_max: float = 3.0         # max (throttle) accel command [m/s^2]
    # ---- EV powertrain / energy parameters ----
    eta_drive: float = 0.92    # tractive (battery->wheel) efficiency
    eta_regen: float = 0.65    # regenerative braking recovery efficiency
    regen_a_limit: float = -2.0  # below this decel, friction brakes take over (no regen)
    P_aux: float = 500.0       # constant auxiliary load [W]


def resistive_force(v: float, theta: float, p: VehicleParams) -> float:
    """Total resistive force [N] at speed v on a road of gradient theta [rad]."""
    f_drag = 0.5 * p.rho * p.Cd * p.A * v * v
    f_roll = p.Crr * p.m * p.g * np.cos(theta)
    f_grav = p.m * p.g * np.sin(theta)
    return f_drag + f_roll + f_grav


def step_longitudinal(state, a_cmd, theta, dt, p: VehicleParams):
    """
    Integrate one vehicle one time step.

    state : (p, v, a) position [m], velocity [m/s], realised accel [m/s^2]
    a_cmd : commanded acceleration [m/s^2] (will be clipped to actuator limits)
    theta : road gradient [rad]
    dt    : time step [s]
    returns: new_state (p, v, a), energy_used_J (battery energy this step, >0 draw, <0 recovered)
    """
    pos, v, a = state
    a_cmd = float(np.clip(a_cmd, p.a_min, p.a_max))

    # first-order actuator lag (semi-implicit for stability)
    a_new = a + (a_cmd - a) * (dt / p.tau)
    # integrate kinematics (a_new is the realised acceleration)
    v_new = v + a_new * dt
    v_new = float(np.clip(v_new, 0.0, p.v_max))
    # if we hit the speed floor/ceiling, realised accel is effectively clamped
    if v_new <= 0.0:
        a_new = (v_new - v) / dt
    pos_new = pos + 0.5 * (v + v_new) * dt

    # ---- energy accounting (EV powertrain) ----
    v_mid = 0.5 * (v + v_new)
    F_trac = p.m * a_new + resistive_force(v_mid, theta, p)  # tractive force at wheels [N]
    P_wheel = F_trac * v_mid                                  # mechanical power at wheels [W]
    if P_wheel >= 0.0:
        P_batt = P_wheel / max(p.eta_drive, 1e-6)             # battery must supply more than wheels
    else:
        # braking: recover only within the regen envelope
        if a_new >= p.regen_a_limit:
            P_batt = P_wheel * p.eta_regen                    # negative -> energy returned
        else:
            P_batt = 0.0                                      # hard braking dissipated by friction
    energy_J = (P_batt + p.P_aux) * dt

    return (pos_new, v_new, a_new), energy_J


def desired_spacing(v, h, d0):
    """Constant-time-headway desired gap: d_des = d0 + h*v."""
    return d0 + h * v
