"""Robust CACC under intermittent V2X dropout in mixed human-RL traffic.

A compact, reproducible simulation toolkit for the next-paper study.
"""
from .dynamics import VehicleParams, step_longitudinal, resistive_force, desired_spacing
from .idm import IDMParams, idm_accel, sample_idm_population
from .v2x import V2XParams, V2XChannel
from .controllers import PIDACC, MPCACC, CACC, SmoothCACC, PlantInvertingCACC, DwellHysteresisCACC, RLPolicy
from .platoon import Platoon, PlatoonConfig, VEHICLE_LENGTH
from .string_stability import (velocity_tf, acc_velocity_tf, cacc_velocity_tf,
                               effective_tf, string_stability_index_freq,
                               time_domain_amplification, disturbance_growth)
from .metrics import compute_metrics, metrics_table, time_to_collision
from . import scenarios
from . import plotting

__all__ = [
    "VehicleParams", "step_longitudinal", "resistive_force", "desired_spacing",
    "IDMParams", "idm_accel", "sample_idm_population",
    "V2XParams", "V2XChannel",
    "PIDACC", "MPCACC", "CACC", "SmoothCACC", "PlantInvertingCACC", "DwellHysteresisCACC", "RLPolicy",
    "Platoon", "PlatoonConfig", "VEHICLE_LENGTH",
    "velocity_tf", "acc_velocity_tf", "cacc_velocity_tf", "effective_tf",
    "string_stability_index_freq",
    "time_domain_amplification", "disturbance_growth",
    "compute_metrics", "metrics_table", "time_to_collision",
    "scenarios", "plotting",
]
