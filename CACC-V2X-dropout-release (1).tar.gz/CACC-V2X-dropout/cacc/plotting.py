"""
Publication-quality plotting helpers (matplotlib only).

A single ``set_pub_style()` call gives consistent, journal-ready figures:
serif fonts, restrained colours, light grids, and high-DPI export. All figure
functions return the Matplotlib Figure so notebooks can save vector PDFs.
"""
from __future__ import annotations
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib import cm


# Colour-blind-friendly palette (Wong, 2011)
PALETTE = {
    "blue": "#0072B2", "orange": "#E69F00", "green": "#009E73",
    "red": "#D55E00", "purple": "#CC79A7", "yellow": "#F0E442",
    "sky": "#56B4E9", "black": "#000000", "grey": "#7f7f7f",
}


def set_pub_style():
    mpl.rcParams.update({
        "figure.dpi": 120,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "font.family": "serif",
        "font.serif": ["DejaVu Serif", "Times New Roman", "Times"],
        "mathtext.fontset": "dejavuserif",
        "font.size": 11,
        "axes.titlesize": 12,
        "axes.labelsize": 11,
        "axes.linewidth": 0.9,
        "axes.grid": True,
        "grid.alpha": 0.30,
        "grid.linewidth": 0.6,
        "legend.frameon": True,
        "legend.framealpha": 0.92,
        "legend.fontsize": 9.5,
        "lines.linewidth": 1.8,
        "xtick.direction": "in",
        "ytick.direction": "in",
        "figure.autolayout": False,
    })


def platoon_colors(n):
    return [cm.viridis(x) for x in np.linspace(0.05, 0.9, n)]


def save(fig, path):
    fig.savefig(path, dpi=300, bbox_inches="tight")
    fig.savefig(path.replace(".pdf", ".png"), dpi=200, bbox_inches="tight")
    return path


# --------------------------------------------------------------------------- #
def plot_string_stability_tf(curves, w=None, figsize=(6.4, 4.0)):
    """curves: list of (label, omega, magnitude, color)."""
    fig, ax = plt.subplots(figsize=figsize)
    for label, om, mag, color in curves:
        ax.semilogx(om, 20 * np.log10(mag), label=label, color=color)
    ax.axhline(0.0, color=PALETTE["black"], ls="--", lw=1.0,
               label=r"string-stability limit ($|G|=1$)")
    ax.set_xlabel(r"frequency $\omega$ [rad/s]")
    ax.set_ylabel(r"$|G(j\omega)|$ [dB]")
    ax.set_title("Velocity transfer-function magnitude")
    ax.legend(loc="best")
    return fig


def plot_platoon_velocities(log, figsize=(7.0, 4.2)):
    t = log["t"]
    vel = log["vel"]
    n = vel.shape[1]
    colors = platoon_colors(n)
    fig, ax = plt.subplots(figsize=figsize)
    ax.plot(t, vel[:, 0], color=PALETTE["black"], lw=2.2, label="lead")
    for i in range(1, n):
        ax.plot(t, vel[:, i], color=colors[i], label=f"veh {i}")
    ax.set_xlabel("time [s]")
    ax.set_ylabel("velocity [m/s]")
    ax.set_title("Disturbance propagation along the platoon")
    ax.legend(ncol=2, loc="best", fontsize=8.5)
    return fig


def plot_amplification(amp_dict, figsize=(6.4, 4.0)):
    """amp_dict: {label: amplification_array (incl. lead at idx 0)}."""
    fig, ax = plt.subplots(figsize=figsize)
    markers = ["o", "s", "^", "D", "v", "P"]
    for j, (label, amp) in enumerate(amp_dict.items()):
        idx = np.arange(len(amp))
        ax.plot(idx, amp, marker=markers[j % len(markers)], label=label)
    ax.axhline(1.0, color=PALETTE["black"], ls="--", lw=1.0,
               label="string-stability limit")
    ax.set_xlabel("vehicle index (upstream $\\rightarrow$)")
    ax.set_ylabel("peak-to-peak velocity / lead")
    ax.set_title("Empirical disturbance amplification")
    ax.legend(loc="best")
    return fig


def plot_phase_diagram(P, R, Z, zlabel, title, figsize=(6.6, 4.6),
                       contour_level=None, cmap="RdYlGn_r"):
    """Heatmap of metric Z over dropout prob P (x) and RL penetration R (y)."""
    fig, ax = plt.subplots(figsize=figsize)
    im = ax.pcolormesh(P, R, Z, shading="auto", cmap=cmap)
    cb = fig.colorbar(im, ax=ax)
    cb.set_label(zlabel)
    if contour_level is not None:
        cs = ax.contour(P, R, Z, levels=[contour_level],
                        colors="k", linewidths=1.6, linestyles="--")
        ax.clabel(cs, fmt={contour_level: f"{zlabel} = {contour_level:g}"},
                  fontsize=8)
    ax.set_xlabel("V2X dropout probability $p_{drop}$")
    ax.set_ylabel("RL-CACC penetration rate")
    ax.set_title(title)
    return fig


def plot_scenario_panel(log, follower=0, figsize=(7.2, 6.2)):
    """4-panel per-follower view: gap, speeds, accel, V2X availability."""
    t = log["t"]
    fig, axes = plt.subplots(4, 1, figsize=figsize, sharex=True)
    gap = log["gap"][:, follower]
    v = log["vel"][:, follower + 1]
    v_lead = log["vel"][:, follower]
    a = log["acc"][:, follower + 1]
    rec = log["v2x_received"][:, follower].astype(float)

    axes[0].plot(t, gap, color=PALETTE["blue"], label=r"$d_{rel}$")
    axes[0].axhline(0.0, color=PALETTE["red"], ls="--", lw=1.0, label="collision")
    axes[0].set_ylabel("gap [m]"); axes[0].legend(loc="best", fontsize=8.5)

    axes[1].plot(t, v, color=PALETTE["blue"], label="ego")
    axes[1].plot(t, v_lead, color=PALETTE["orange"], ls="--", label="leader")
    axes[1].set_ylabel("speed [m/s]"); axes[1].legend(loc="best", fontsize=8.5)

    axes[2].plot(t, a, color=PALETTE["green"], label="accel")
    axes[2].set_ylabel(r"accel [m/s$^2$]"); axes[2].legend(loc="best", fontsize=8.5)

    axes[3].fill_between(t, 0, rec, step="mid", color=PALETTE["sky"], alpha=0.7)
    axes[3].set_ylabel("V2X up"); axes[3].set_ylim(-0.1, 1.1)
    axes[3].set_yticks([0, 1]); axes[3].set_yticklabels(["lost", "ok"])
    axes[3].set_xlabel("time [s]")
    fig.suptitle(f"Follower #{follower + 1} response", y=0.995)
    return fig
