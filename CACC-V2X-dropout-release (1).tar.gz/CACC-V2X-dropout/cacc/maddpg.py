"""
Dropout-aware, shared-policy multi-agent TD3 with a V2X gating mechanism.

Twin-Delayed Deep Deterministic policy gradient (Fujimoto et al. 2018),
specialised for a homogeneous multi-agent platoon and intermittent V2X:

* **Shared policy** - all followers share one gated actor (parameter sharing).
* **Decentralised, per-agent twin critics** - a single shared critic pair
  Q1, Q2(o_i, xi_i) scores only the local observation/action of one agent; there
  is no joint-observation, joint-action centralised critic. Because the critic
  is parameter-shared and evaluated per-agent, every environment step yields
  |N| independent training transitions from a single rollout.
* **TD3 stabilisers** - clipped target-policy smoothing noise, twin critics
  with a min-target to curb value overestimation, and delayed (every 2nd
  critic step) actor updates.
* **Gating mechanism** - each actor contains a small gate network that, from
  the dropout flag and message age, outputs a reliability weight g in [0,1]
  and blends the V2X leader-acceleration estimate with the onboard (radar)
  estimate as a_lead_eff = g*a_v2x + (1-g)*a_onboard before the policy head.

Implementation is intentionally compact and CPU-friendly.
"""
from __future__ import annotations
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from .marl_env import OBS_DIM, ACT_DIM, OBS_KEYS

# indices of the V2X / onboard leader-accel fields inside the normalised obs
I_A_LEAD_ONBOARD = OBS_KEYS.index("a_lead_onboard")
I_V2X_A = OBS_KEYS.index("v2x_a")
I_V2X_V = OBS_KEYS.index("v2x_v")
I_DROPOUT = OBS_KEYS.index("dropout_flag")
I_MSG_AGE = OBS_KEYS.index("msg_age")


class GatedActor(nn.Module):
    """Gated policy network.

    Parameters
    ----------
    hide_raw_comm : bool
        If True, the raw v2x_a / v2x_v fields are withheld from the policy
        head after gating, so the actor can only see the physical state plus
        the gated blend a_lead_eff -- not the raw communicated values. This is
        the "stronger ablation" that removes the actor's ability to bypass
        the gate and infer link reliability directly from the raw observation
        (see the gate-causality ablation).
    """

    def __init__(self, obs_dim=OBS_DIM, act_dim=ACT_DIM, hidden=128,
                 hide_raw_comm: bool = False):
        super().__init__()
        self.hide_raw_comm = hide_raw_comm
        # gate: from [dropout_flag, msg_age] -> reliability weight g in [0,1]
        self.gate = nn.Sequential(nn.Linear(2, 32), nn.ReLU(),
                                  nn.Linear(32, 1), nn.Sigmoid())
        if hide_raw_comm:
            self._keep_idx = [i for i in range(obs_dim) if i not in (I_V2X_A, I_V2X_V)]
        else:
            self._keep_idx = list(range(obs_dim))
        net_in = len(self._keep_idx) + 1  # + a_lead_eff
        self.net = nn.Sequential(
            nn.Linear(net_in, hidden), nn.LayerNorm(hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, act_dim), nn.Tanh())
        # near-zero output-layer init (Table: "weights x0.05")
        out_lin = self.net[-2]
        with torch.no_grad():
            out_lin.weight.mul_(0.05)
            out_lin.bias.mul_(0.05)

    def forward(self, obs):
        g = self.gate(obs[..., [I_DROPOUT, I_MSG_AGE]])
        a_lead_eff = g * obs[..., I_V2X_A:I_V2X_A + 1] + \
            (1 - g) * obs[..., I_A_LEAD_ONBOARD:I_A_LEAD_ONBOARD + 1]
        obs_in = obs[..., self._keep_idx]
        x = torch.cat([obs_in, a_lead_eff], dim=-1)
        return self.net(x), g


class TwinCritic(nn.Module):
    """Decentralised, per-agent twin critic Q1, Q2(o_i, xi_i).

    Parameter-shared across agents: takes ONE agent's local observation and
    action (obs_dim + act_dim inputs), never the joint state/action of the
    platoon. This is the architecture the manuscript describes ("no
    centralised critic or explicit joint-agent information during training").
    """

    def __init__(self, obs_dim=OBS_DIM, act_dim=ACT_DIM, hidden=128):
        super().__init__()
        def _mlp():
            return nn.Sequential(
                nn.Linear(obs_dim + act_dim, hidden), nn.ReLU(),
                nn.Linear(hidden, hidden), nn.ReLU(),
                nn.Linear(hidden, 1))
        self.q1 = _mlp()
        self.q2 = _mlp()

    def forward(self, obs, act):
        x = torch.cat([obs, act], dim=-1)
        return self.q1(x), self.q2(x)

    def q1_value(self, obs, act):
        return self.q1(torch.cat([obs, act], dim=-1))


class ReplayBuffer:
    def __init__(self, capacity, n_agents):
        self.cap = capacity
        self.n = n_agents
        self.buf = []
        self.pos = 0

    def push(self, o, a, r, o2, d):
        item = (o, a, r, o2, d)
        if len(self.buf) < self.cap:
            self.buf.append(item)
        else:
            self.buf[self.pos] = item
        self.pos = (self.pos + 1) % self.cap

    def sample(self, batch):
        idx = np.random.randint(0, len(self.buf), size=batch)
        o, a, r, o2, d = zip(*[self.buf[i] for i in idx])
        to = lambda x: torch.as_tensor(np.array(x), dtype=torch.float32)
        return to(o), to(a), to(r), to(o2), to(d)

    def __len__(self):
        return len(self.buf)


class MADDPG:
    """Shared-policy multi-agent TD3 (class name kept for notebook compatibility).

    ``shared_actor=True`` and a single parameter-shared TwinCritic together
    implement the paper's "shared-policy multi-agent TD3": one gated actor and
    one decentralised twin-critic pair, both evaluated independently per agent.
    """

    def __init__(self, n_agents, device="cpu", lr_actor=3e-4, lr_critic=5e-4,
                 gamma=0.97, tau=0.01, shared_actor=True,
                 target_noise_sigma=0.2, target_noise_clip=0.5,
                 policy_delay=2, grad_clip_norm=1.0,
                 action_penalty=0.02, hide_raw_comm=False):
        if not shared_actor:
            raise NotImplementedError(
                "Only the shared-policy configuration (parameter sharing across "
                "agents) matches the manuscript's design; per-agent independent "
                "networks are not implemented.")
        self.n = n_agents
        self.device = torch.device(device)
        self.gamma, self.tau = gamma, tau
        self.target_noise_sigma = target_noise_sigma
        self.target_noise_clip = target_noise_clip
        self.policy_delay = policy_delay
        self.grad_clip_norm = grad_clip_norm
        self.action_penalty = action_penalty
        self.total_it = 0

        self.actor = GatedActor(hide_raw_comm=hide_raw_comm).to(self.device)
        self.actor_t = GatedActor(hide_raw_comm=hide_raw_comm).to(self.device)
        self.critic = TwinCritic().to(self.device)
        self.critic_t = TwinCritic().to(self.device)
        self._hard_update()
        self.opt_a = torch.optim.Adam(self.actor.parameters(), lr=lr_actor)
        self.opt_c = torch.optim.Adam(self.critic.parameters(), lr=lr_critic)

    # -- kept for API compatibility with code that indexed per-agent actors --
    def _actor(self, i):
        return self.actor

    def _actor_t(self, i):
        return self.actor_t

    def _hard_update(self):
        self.actor_t.load_state_dict(self.actor.state_dict())
        self.critic_t.load_state_dict(self.critic.state_dict())

    def _soft(self, net, net_t):
        for p, pt in zip(net.parameters(), net_t.parameters()):
            pt.data.copy_(self.tau * p.data + (1 - self.tau) * pt.data)

    @torch.no_grad()
    def act(self, obs_arr, noise=0.0):
        """obs_arr: (n_agents, obs_dim) -> (n_agents, act_dim) in [-1,1]."""
        o = torch.as_tensor(obs_arr, dtype=torch.float32, device=self.device)
        a, _ = self.actor(o)
        a = a.cpu().numpy()
        if noise > 0:
            a = np.clip(a + noise * np.random.randn(*a.shape), -1, 1)
        return a

    def update(self, buffer, batch=256):
        """One TD3 update. Critic updates every call; actor + targets are
        delayed to every ``policy_delay``-th call, per the TD3 recipe."""
        if len(buffer) < batch:
            return None
        o, a, r, o2, d = buffer.sample(batch)
        o, a, r, o2, d = [x.to(self.device) for x in (o, a, r, o2, d)]
        B, N = o.shape[0], o.shape[1]

        # Flatten the agent dimension: the critic and actor are decentralised
        # and parameter-shared, so each agent's transition is an independent
        # sample -- exactly the "|N| independent transitions per env step"
        # the manuscript describes.
        o_f = o.reshape(B * N, -1)
        a_f = a.reshape(B * N, -1)
        r_f = r.reshape(B * N, 1)
        o2_f = o2.reshape(B * N, -1)
        d_f = d.reshape(B * N, 1)

        with torch.no_grad():
            a2, _ = self.actor_t(o2_f)
            noise = (torch.randn_like(a2) * self.target_noise_sigma
                     ).clamp(-self.target_noise_clip, self.target_noise_clip)
            a2 = (a2 + noise).clamp(-1.0, 1.0)
            q1_t, q2_t = self.critic_t(o2_f, a2)
            q_t = torch.min(q1_t, q2_t)
            y = r_f + self.gamma * (1 - d_f) * q_t

        q1, q2 = self.critic(o_f, a_f)
        c_loss = F.mse_loss(q1, y) + F.mse_loss(q2, y)
        self.opt_c.zero_grad()
        c_loss.backward()
        nn.utils.clip_grad_norm_(self.critic.parameters(), self.grad_clip_norm)
        self.opt_c.step()

        out = {"critic_loss": c_loss.item(), "actor_loss": None}
        self.total_it += 1
        if self.total_it % self.policy_delay == 0:
            xi, _ = self.actor(o_f)
            a_loss = -self.critic.q1_value(o_f, xi).mean() \
                + self.action_penalty * (xi ** 2).mean()
            self.opt_a.zero_grad()
            a_loss.backward()
            nn.utils.clip_grad_norm_(self.actor.parameters(), self.grad_clip_norm)
            self.opt_a.step()
            self._soft(self.actor, self.actor_t)
            self._soft(self.critic, self.critic_t)
            out["actor_loss"] = a_loss.item()
        return out

    # convenience: expose a numpy actor for the RLPolicy adapter
    def make_actor_fn(self, agent=0):
        net = self.actor
        def fn(obs_vec):
            with torch.no_grad():
                o = torch.as_tensor(obs_vec, dtype=torch.float32,
                                    device=self.device).unsqueeze(0)
                a, _ = net(o)
                return a.cpu().numpy().ravel()
        return fn

    def gate_fn(self):
        """Numpy callable g(dropout_flag, msg_age) -> gate value, for plots/ablations."""
        net = self.actor
        @torch.no_grad()
        def fn(dropout_flag, msg_age):
            x = torch.tensor([[dropout_flag, msg_age]], dtype=torch.float32)
            return net.gate(x).item()
        return fn
