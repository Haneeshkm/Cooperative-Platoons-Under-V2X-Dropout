"""
Canonical evaluation protocol for the CACC-V2X-dropout study.

This module is the single source of truth for how every table and figure in the
paper computes string stability, jerk, and energy from a rollout. Earlier
development of this project accumulated several near-duplicate copies of this
logic across ad-hoc scripts; consolidating it here means every reproduction
script (see ``scripts/``) calls the same, tested code path.

Key entry points:
    steady_state_gamma(log, omega)   -- Eq. (12) of the paper: peak-to-peak growth
                                         over the last 3 disturbance periods.
    rms_jerk(log), energy_kwh_per_100km(log)
    run_rollout(...)                 -- build and run one Platoon rollout under the
                                         canonical scenario (sinusoidal disturbance,
                                         V2X dropout, IDM humans for any non-
                                         controlled followers).
    evaluate(...)                    -- run_rollout + metrics, averaged over a set
                                         of evaluation seeds.
    forced_gate_actor_fn(actor, g)   -- wrap a trained GatedActor so its gate is
                                         pinned to a constant at test time (the
                                         g=0 / g=1 ablation used throughout).
    build_mixed_types(...)           -- sample a penetration-fraction 'controlled'
                                         vs 'human' assignment for the mixed-
                                         autonomy sweep.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Optional, Sequence

import numpy as np
import torch

from .controllers import RLPolicy
from .platoon import Platoon, PlatoonConfig
from .maddpg import GatedActor, I_A_LEAD_ONBOARD, I_V2X_A
from .marl_env import OBS_KEYS
from .v2x import V2XParams
from .idm import sample_idm_population
from . import scenarios

# ----------------------------------------------------------------------------- #
# Canonical protocol constants (Section "Simulation Setup and Scenarios" of the
# paper). Changing these changes what "the canonical protocol" means everywhere,
# so treat them as part of the paper's definitions, not free parameters.
CANONICAL_EVAL_SEEDS = list(range(5, 10))   # five evaluation seeds, disjoint from
                                             # training seeds (10-14 in this study)
CANONICAL_OMEGA = 0.45          # rad/s, disturbance probe frequency
CANONICAL_AMPLITUDE = 3.0       # m/s
CANONICAL_N_FOLLOWERS = 8       # "one leader plus eight followers"
CANONICAL_P_DROP = 0.3          # default dropout probability
CANONICAL_DT = 0.1              # s
CANONICAL_T = 120.0             # s, evaluation horizon at the canonical frequency
CANONICAL_INIT_GAP = 20.0       # m
CANONICAL_INIT_SPEED = 25.0     # m/s
CANONICAL_DELAY_STEPS = 1       # one simulation step (~100 ms) V2X transport delay


# ----------------------------------------------------------------------------- #
def steady_state_gamma(log: dict, omega: float = CANONICAL_OMEGA,
                        dt: float = CANONICAL_DT, M: int = 3) -> float:
    """Eq. (12): peak-to-peak velocity growth over the last M complete disturbance
    periods, normalised by the lead vehicle's peak-to-peak. This is Gamma* as
    reported in every table of the paper -- NOT the same as
    ``string_stability.steady_state_growth``, which uses a fixed fraction of the
    horizon rather than an exact multiple of the disturbance period and is kept
    in that module only for backward compatibility with the original notebooks.
    """
    T_p = 2 * np.pi / omega
    window = int(np.ceil(M * T_p / dt))
    vel = log["vel"]
    k0 = max(0, vel.shape[0] - window)
    seg = vel[k0:]
    ptp = seg.max(axis=0) - seg.min(axis=0)
    ref = max(ptp[0], 1e-6)
    return float(np.max(ptp[1:] / ref))


def rms_jerk(log: dict, dt: float = CANONICAL_DT) -> float:
    jerk = np.diff(log["acc"][:, 1:], axis=0) / dt
    return float(np.sqrt(np.mean(jerk ** 2)))


def energy_kwh_per_100km(log: dict, dt: float = CANONICAL_DT) -> float:
    total_J = log["energy_J"].sum()
    dist_m = (log["vel"][:, 1:].sum(axis=0) * dt).sum()
    kWh = total_J / 3.6e6
    return float((kWh / max(dist_m / 1000.0, 1e-6)) * 100.0)


# ----------------------------------------------------------------------------- #
def actor_to_fn(actor: torch.nn.Module) -> Callable[[np.ndarray], np.ndarray]:
    """Wrap a GatedActor (or any obs-vector -> action-vector module) as the plain
    numpy callable RLPolicy expects."""
    def fn(obs_vec):
        with torch.no_grad():
            o = torch.as_tensor(obs_vec, dtype=torch.float32).unsqueeze(0)
            out = actor(o)
            a = out[0] if isinstance(out, tuple) else out
            return a.cpu().numpy().ravel()
    return fn


def forced_gate_actor_fn(actor: GatedActor, g_value: float) -> Callable[[np.ndarray], np.ndarray]:
    """Wrap a trained GatedActor so its gate is pinned to a constant g_value in
    [0, 1] at test time, bypassing the gate network entirely but reusing the
    trained policy head. This is the g=0 (onboard only) / g=1 (always trust V2X)
    ablation used in Table "Isolating the gate" and throughout Section
    "Learned Controller" of the paper.
    """
    keep_idx = actor._keep_idx
    def fn(obs_vec):
        with torch.no_grad():
            o = torch.as_tensor(obs_vec, dtype=torch.float32).unsqueeze(0)
            a_lead_eff = (g_value * o[..., I_V2X_A:I_V2X_A + 1]
                          + (1 - g_value) * o[..., I_A_LEAD_ONBOARD:I_A_LEAD_ONBOARD + 1])
            obs_in = o[..., keep_idx]
            x = torch.cat([obs_in, a_lead_eff], dim=-1)
            return actor.net(x).cpu().numpy().ravel()
    return fn


def build_mixed_types(n: int, penetration: float, rng: np.random.Generator) -> list:
    """Sample a 'controlled' vs 'human' assignment with the given penetration
    fraction, used for the mixed-autonomy sweep. Matches the role-assignment
    logic in marl_env.PlatoonMARLEnv._assign_roles."""
    n_ctrl = max(1, int(round(penetration * n)))
    mask = np.array([1] * n_ctrl + [0] * (n - n_ctrl))
    rng.shuffle(mask)
    return ["controlled" if m else "human" for m in mask]


# ----------------------------------------------------------------------------- #
@dataclass
class RolloutResult:
    log: dict
    gamma: float
    jerk: float
    energy: float
    stable: bool


def run_rollout(make_controllers, seed: int, *, n_followers: int = CANONICAL_N_FOLLOWERS,
                 p_drop: float = CANONICAL_P_DROP, omega: float = CANONICAL_OMEGA,
                 amplitude: float = CANONICAL_AMPLITUDE, T: Optional[float] = None,
                 penetration: float = 1.0, v2x_params: Optional[V2XParams] = None,
                 dt: float = CANONICAL_DT) -> RolloutResult:
    """Run one canonical-protocol rollout and compute its metrics.

    ``make_controllers(n_followers)`` must return a list of length n_followers;
    entries for 'human' positions (when penetration < 1) are ignored and may be
    None. For penetration == 1.0 every position is 'controlled'.

    T defaults to CANONICAL_T (120s), matching the paper's fixed-omega=0.45
    protocol. At LOW disturbance frequencies (omega below roughly 0.15 rad/s)
    120s covers fewer than the 3 full periods steady_state_gamma's window
    wants; scripts/run_frequency_sweep.py passes an explicit, period-scaled T
    for exactly this reason -- don't rely on the default when varying omega
    over a wide range.
    """
    rng = np.random.default_rng(seed)
    types = (["controlled"] * n_followers if penetration >= 1.0
             else build_mixed_types(n_followers, penetration, rng))
    controllers_all = make_controllers(n_followers)
    controllers = [c if t == "controlled" else None for c, t in zip(controllers_all, types)]

    T = T if T is not None else CANONICAL_T
    lead = scenarios.highway_cruise(v=CANONICAL_INIT_SPEED, amp=amplitude,
                                     period=2 * np.pi / omega)
    cfg = PlatoonConfig(n_followers=n_followers, dt=dt, T=T,
                         init_gap=CANONICAL_INIT_GAP, init_speed=CANONICAL_INIT_SPEED)
    v2xp = v2x_params or V2XParams(mode="bernoulli", p_drop=p_drop,
                                    delay_steps=CANONICAL_DELAY_STEPS)
    pl = Platoon(cfg, lead, types, controllers,
                 human_params=sample_idm_population(n_followers, rng),
                 v2x_params=v2xp, rng=rng)
    log = pl.run()
    gamma = steady_state_gamma(log, omega=omega, dt=dt)
    return RolloutResult(log=log, gamma=gamma, jerk=rms_jerk(log, dt=dt),
                          energy=energy_kwh_per_100km(log, dt=dt),
                          stable=gamma <= 1.0 + 1e-6)


@dataclass
class EvalSummary:
    gamma_mean: float
    gamma_std: float
    gamma_all: list
    f_stable: float
    jerk_mean: float
    energy_mean: float

    def as_dict(self) -> dict:
        return {"gamma_mean": self.gamma_mean, "gamma_std": self.gamma_std,
                "gamma_all": self.gamma_all, "f_stable": self.f_stable,
                "jerk_mean": self.jerk_mean, "energy_mean": self.energy_mean}


def evaluate(make_controllers, *, seeds: Sequence[int] = CANONICAL_EVAL_SEEDS,
             **rollout_kwargs) -> EvalSummary:
    """Average run_rollout over a set of evaluation seeds -- the standard
    "five-seed mean +/- std" reported throughout the paper."""
    results = [run_rollout(make_controllers, s, **rollout_kwargs) for s in seeds]
    gammas = np.array([r.gamma for r in results])
    return EvalSummary(
        gamma_mean=float(gammas.mean()), gamma_std=float(gammas.std()),
        gamma_all=gammas.tolist(), f_stable=float(np.mean([r.stable for r in results])),
        jerk_mean=float(np.mean([r.jerk for r in results])),
        energy_mean=float(np.mean([r.energy for r in results])),
    )


def make_rl_controllers(actor: GatedActor, n: int) -> list:
    """Build n independent RLPolicy controllers sharing one trained actor
    (the shared-policy design: one network, evaluated per-agent)."""
    return [RLPolicy(actor_to_fn(actor), OBS_KEYS) for _ in range(n)]


def load_actor(path: str, hide_raw_comm: Optional[bool] = None) -> GatedActor:
    """Load a trained actor checkpoint saved by scripts/train.py."""
    ckpt = torch.load(path, weights_only=False)
    hrc = ckpt["hide_raw_comm"] if hide_raw_comm is None else hide_raw_comm
    actor = GatedActor(hide_raw_comm=hrc)
    actor.load_state_dict(ckpt["actor_state"])
    actor.eval()
    return actor
