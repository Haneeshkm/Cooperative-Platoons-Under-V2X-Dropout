"""
Longitudinal controllers for the platoon.

All controllers share the signature::

    a_cmd = controller(obs) -> float

where ``obs`` is a dict produced by the platoon simulator containing the local
(onboard) measurements and, optionally, a V2X payload + dropout flag.

Implemented:
  * PIDACC   - classic constant-time-headway PD/PID ACC (onboard only)
  * MPCACC   - short-horizon QP MPC (onboard only)
  * CACC     - constant-time-headway CACC with predecessor-accel feedforward
               from V2X; gracefully degrades to ACC when the message is lost.
  * RLPolicy - adapter wrapping a trained (MA)RL actor.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from .dynamics import desired_spacing
from .marl_env import normalize_obs


# --------------------------------------------------------------------------- #
@dataclass
class PIDACC:
    h: float = 1.5      # time headway [s]
    d0: float = 5.0     # standstill spacing [m]
    kp: float = 0.20    # gap error gain
    kd: float = 0.70    # relative-velocity gain
    ki: float = 0.0     # integral gain
    a_min: float = -6.0
    a_max: float = 3.0

    def reset(self):
        self._integ = 0.0

    def __call__(self, obs):
        if not hasattr(self, "_integ"):
            self.reset()
        gap, v, v_lead = obs["gap"], obs["v"], obs["v_lead"]
        d_des = desired_spacing(v, self.h, self.d0)
        e = gap - d_des
        self._integ += e * obs.get("dt", 0.1)
        a = self.kp * e + self.kd * (v_lead - v) + self.ki * self._integ
        return float(np.clip(a, self.a_min, self.a_max))


# --------------------------------------------------------------------------- #
@dataclass
class CACC:
    """Constant-time-headway CACC with predecessor acceleration feedforward.

    a = kp*(gap - d_des) + kd*(v_lead - v) + kff * a_pred_received

    The feedforward term is what gives CACC its tight (string-stable) behaviour
    and short time headway. When the V2X message is dropped, the feedforward is
    unavailable; the controller falls back to the ACC law (kff -> 0) and, to
    stay safe, opens up the headway. This degradation is exactly the failure
    mode the dropout-aware RL policy is designed to overcome.
    """
    h: float = 0.6          # short CACC headway (perfect comms)
    h_fallback: float = 1.5  # safe ACC headway used while comms are down
    d0: float = 5.0
    kp: float = 0.20
    kd: float = 0.70
    kff: float = 1.0
    a_min: float = -6.0
    a_max: float = 3.0

    def reset(self):
        pass

    def __call__(self, obs):
        gap, v, v_lead = obs["gap"], obs["v"], obs["v_lead"]
        received = obs.get("v2x_received", False)
        a_pred = obs.get("v2x_a", 0.0)
        h = self.h if received else self.h_fallback
        d_des = desired_spacing(v, h, self.d0)
        a = self.kp * (gap - d_des) + self.kd * (v_lead - v)
        if received:
            a += self.kff * a_pred
        return float(np.clip(a, self.a_min, self.a_max))


# --------------------------------------------------------------------------- #
@dataclass
class PlantInvertingCACC:
    """Canonical plant-inverting CACC (Ploeg/Naus-style): under this project's
    actuator model (first-order lag tau, plant U_i(s) = s(tau*s+1)*V_i(s)), the
    control law

        u_i = (tau/h)*(a_hat_{i-1} - a_i) + (1/h)*(v_hat_{i-1} - v_i)
              + kp_outer*(gap_i - d_des,i)

    yields the closed-loop velocity transfer function G(s) = 1/(1+h*s) EXACTLY
    (verified symbolically), matching the ideal form eq:gcacc, for ANY h > 0 --
    unlike the paper's "implemented additive-feedforward" baseline (CACC above),
    whose kff*a_hat feedforward does not invert the actuator lag and so only
    approximates G_cacc. kp_outer regulates absolute spacing (needed in practice
    to prevent gap drift, since the pure velocity-matching law above has no
    absolute-position reference) and was verified numerically to leave sup|G|=1
    unchanged for kp_outer up to 0.2 (used here at 0.1).

    This is the "canonical plant-inverting CACC comparator" baseline: a
    genuinely string-stable-by-construction (at h>0, full reception) classical
    controller, used to re-run the dropout-handling ablation and check whether
    the paper's "switching, not feedforward loss, destabilises CACC" conclusion
    is an artefact of the specific (non-canonical) additive-feedforward design.

    ``mode`` selects how this controller degrades under V2X loss, mirroring the
    three conditions in Table tab:ablation:
      - "switch"       : binary headway switch to h_fallback AND drop to the
                         onboard PD-ACC law (kp_outer, kd_fallback on relative
                         velocity) when unreceived -- the discontinuous baseline.
      - "ff_drop_only" : headway stays at h (never switches); only the
                         feedforward/velocity-matching terms are zeroed when
                         unreceived, falling back to onboard PD-ACC at h.
      - "smooth"        : continuous reliability-weighted blend of the
                         plant-inverting law and the onboard PD-ACC fallback,
                         exactly mirroring SmoothCACC's r=exp(-age/tau_r).
    """
    h: float = 0.6
    h_fallback: float = 1.5
    d0: float = 5.0
    tau_act: float = 0.3
    kp_outer: float = 0.1
    kd_fallback: float = 0.70
    kp_fallback: float = 0.20
    tau_r: float = 2.0
    mode: str = "switch"
    a_min: float = -6.0
    a_max: float = 3.0

    def reset(self):
        self._last_a_pred = 0.0
        self._last_v_pred = None

    def _onboard_fallback(self, gap, v, v_lead, h):
        d_des = desired_spacing(v, h, self.d0)
        return self.kp_fallback * (gap - d_des) + self.kd_fallback * (v_lead - v)

    def _plant_inverting(self, gap, v, v_lead, a_self, a_pred_used, v_pred_used, h):
        d_des = desired_spacing(v, h, self.d0)
        a = (self.tau_act / h) * (a_pred_used - a_self) \
            + (1.0 / h) * (v_pred_used - v) \
            + self.kp_outer * (gap - d_des)
        return a

    def __call__(self, obs):
        if not hasattr(self, "_last_a_pred"):
            self.reset()
        gap, v, v_lead = obs["gap"], obs["v"], obs["v_lead"]
        a_self = obs.get("a_self", 0.0)
        received = obs.get("v2x_received", False)
        v2x_a = obs.get("v2x_a", 0.0)
        v2x_v = obs.get("v2x_v", v_lead)

        if self.mode == "switch":
            if received:
                a = self._plant_inverting(gap, v, v_lead, a_self, v2x_a, v2x_v, self.h)
            else:
                a = self._onboard_fallback(gap, v, v_lead, self.h_fallback)
        elif self.mode == "ff_drop_only":
            if received:
                a = self._plant_inverting(gap, v, v_lead, a_self, v2x_a, v2x_v, self.h)
            else:
                a = self._onboard_fallback(gap, v, v_lead, self.h)  # headway NEVER switches
        elif self.mode == "smooth":
            dt = obs.get("dt", 0.1)
            age_s = obs.get("msg_age", 0.0) * 20.0 * dt
            if received:
                self._last_a_pred = v2x_a
                self._last_v_pred = v2x_v
                age_s = 0.0
            elif self._last_v_pred is None:
                self._last_v_pred = v_lead
            r = float(np.exp(-age_s / self.tau_r))
            h_eff = self.h_fallback - (self.h_fallback - self.h) * r
            a_pi = self._plant_inverting(gap, v, v_lead, a_self,
                                          self._last_a_pred, self._last_v_pred, h_eff)
            a_fb = self._onboard_fallback(gap, v, v_lead, h_eff)
            a = r * a_pi + (1 - r) * a_fb
        else:
            raise ValueError(self.mode)
        return float(np.clip(a, self.a_min, self.a_max))


# --------------------------------------------------------------------------- #
@dataclass
class DwellHysteresisCACC:
    """Binary-switching CACC (same fallback law as CACC above) with dwell-time
    hysteresis on the headway switch, to test whether requiring several
    consecutive successes/losses before switching -- rather than switching on
    every single dropped or received packet -- recovers string stability
    without abandoning the discontinuous switch itself.

    Pseudocode (per step, given the current reception flag `received`):
        if received:
            success_streak += 1; loss_streak = 0
            if success_streak >= K_recover: state = SHORT_HEADWAY
        else:
            loss_streak += 1; success_streak = 0
            if loss_streak >= K_degrade: state = FALLBACK_HEADWAY
        h = h_short if state == SHORT_HEADWAY else h_fallback
        a = kp*(gap - (d0 + h*v)) + kd*(v_lead - v) + kff*a_hat_{i-1} if state == SHORT_HEADWAY else 0

    K_degrade=1 (default) switches to fallback on the FIRST lost packet (fast
    degrade, matching the naive baseline's behaviour on loss) while K_recover
    controls how many consecutive successful receptions are required before
    trusting the link enough to return to the short headway (slow return) --
    the asymmetric variant. K_degrade=K_recover reproduces a symmetric
    hysteresis band instead.
    """
    h: float = 0.6
    h_fallback: float = 1.5
    d0: float = 5.0
    kp: float = 0.20
    kd: float = 0.70
    kff: float = 1.0
    K_degrade: int = 1
    K_recover: int = 3
    a_min: float = -6.0
    a_max: float = 3.0

    def reset(self):
        self._short = True   # start trusting the link (short headway)
        self._success_streak = 0
        self._loss_streak = 0

    def __call__(self, obs):
        if not hasattr(self, "_short"):
            self.reset()
        gap, v, v_lead = obs["gap"], obs["v"], obs["v_lead"]
        received = obs.get("v2x_received", False)
        a_pred = obs.get("v2x_a", 0.0)

        if received:
            self._success_streak += 1
            self._loss_streak = 0
            if self._success_streak >= self.K_recover:
                self._short = True
        else:
            self._loss_streak += 1
            self._success_streak = 0
            if self._loss_streak >= self.K_degrade:
                self._short = False

        h = self.h if self._short else self.h_fallback
        d_des = desired_spacing(v, h, self.d0)
        a = self.kp * (gap - d_des) + self.kd * (v_lead - v)
        if self._short and received:
            a += self.kff * a_pred
        return float(np.clip(a, self.a_min, self.a_max))


# --------------------------------------------------------------------------- #
@dataclass
class SmoothCACC:
    """Dropout-aware CACC with CONTINUOUS headway/feedforward scheduling.

    Addresses the reviewers' point that the naive CACC baseline's instantaneous
    switch between h and h_fallback (and the hard zero/kff cutoff on the
    feedforward term) is itself the dominant destabilising mechanism, making it
    an unfairly weak baseline for the learned controller.

    Instead of switching, an exponentially-decaying reliability estimate
    r = exp(-age/tau_r) (age = time since the last received message) is used
    to:
      * interpolate the time headway continuously between h (fresh message)
        and h_fallback (long-stale message), and
      * apply a decaying HOLD of the last received predecessor acceleration
        (a simple observer/predictor), rather than abruptly zeroing the
        feedforward term the instant a message is dropped.

    This is still a classical (non-learned), fully deterministic controller --
    the "continuously scheduled headway/feedforward weighting" / "observer-
    based packet-loss compensation" baseline referenced in the reviews.
    """
    h: float = 0.6
    h_fallback: float = 1.5
    d0: float = 5.0
    kp: float = 0.20
    kd: float = 0.70
    kff: float = 1.0
    tau_r: float = 0.5       # reliability decay time constant [s]
    a_min: float = -6.0
    a_max: float = 3.0

    def reset(self):
        self._last_a_pred = 0.0

    def __call__(self, obs):
        if not hasattr(self, "_last_a_pred"):
            self.reset()
        gap, v, v_lead = obs["gap"], obs["v"], obs["v_lead"]
        received = obs.get("v2x_received", False)
        dt = obs.get("dt", 0.1)
        # msg_age here (from platoon.py) is normalised to [0,1] over a 20-step
        # (2s) window; recover an age in seconds for the decay.
        age_s = obs.get("msg_age", 0.0) * 20.0 * dt
        if received:
            self._last_a_pred = obs.get("v2x_a", 0.0)
            age_s = 0.0
        r = float(np.exp(-age_s / self.tau_r))       # 1.0 when fresh, -> 0 as it stales
        h_eff = self.h_fallback - (self.h_fallback - self.h) * r
        d_des = desired_spacing(v, h_eff, self.d0)
        a = (self.kp * (gap - d_des) + self.kd * (v_lead - v)
             + self.kff * r * self._last_a_pred)
        return float(np.clip(a, self.a_min, self.a_max))


# --------------------------------------------------------------------------- #
class MPCACC:
    """Short-horizon MPC for ACC, solved as a small dense QP each step.

    Minimises  sum_k Qd*(gap_k - d_des_k)^2 + Qv*(v_lead - v_k)^2 + R*a_k^2
    subject to a double-integrator prediction of the headway error and input
    bounds. Uses scipy if available; otherwise a damped analytic fallback.
    """

    def __init__(self, h=1.5, d0=5.0, N=15, dt=0.1,
                 Qd=1.0, Qv=0.6, R=0.4, a_min=-6.0, a_max=3.0):
        self.h, self.d0, self.N, self.dt = h, d0, N, dt
        self.Qd, self.Qv, self.R = Qd, Qv, R
        self.a_min, self.a_max = a_min, a_max

    def reset(self):
        pass

    def __call__(self, obs):
        gap, v, v_lead = obs["gap"], obs["v"], obs["v_lead"]
        N, dt = self.N, self.dt
        # predict assuming constant leader speed over the horizon
        from scipy.optimize import minimize

        def cost(a_seq):
            g, vv, c = gap, v, 0.0
            for k in range(N):
                a = a_seq[k]
                vv_next = vv + a * dt
                g = g + (v_lead - vv) * dt           # gap dynamics
                d_des = self.d0 + self.h * vv_next
                c += self.Qd * (g - d_des) ** 2 + self.Qv * (v_lead - vv_next) ** 2 + self.R * a ** 2
                vv = vv_next
            return c

        a0 = np.zeros(N)
        bounds = [(self.a_min, self.a_max)] * N
        try:
            res = minimize(cost, a0, method="L-BFGS-B", bounds=bounds,
                           options={"maxiter": 40})
            a_cmd = res.x[0]
        except Exception:
            d_des = self.d0 + self.h * v
            a_cmd = 0.4 * (gap - d_des) + 0.5 * (v_lead - v)
        return float(np.clip(a_cmd, self.a_min, self.a_max))


# --------------------------------------------------------------------------- #
class RLPolicy:
    """Adapter that turns a trained actor into the standard controller API.

    ``actor_fn`` maps a flat observation vector -> action in [-1, 1]; we scale
    that to the actuator range. ``obs_keys`` selects which observation fields
    (and in what order) form the policy input, so the same adapter works for
    single-agent and multi-agent actors.
    """

    def __init__(self, actor_fn, obs_keys, a_min=-6.0, a_max=3.0, normalize=True):
        self.actor_fn = actor_fn
        self.obs_keys = obs_keys
        self.a_min, self.a_max = a_min, a_max
        self.normalize = normalize

    def reset(self):
        pass

    def _vector(self, obs):
        if self.normalize:
            # Match the training-time normalisation exactly (see marl_env.normalize_obs);
            # a trained actor otherwise sees raw physical units it never saw in training.
            return normalize_obs(obs)
        return np.array([obs.get(k, 0.0) for k in self.obs_keys], dtype=np.float32)

    def __call__(self, obs):
        u = float(np.asarray(self.actor_fn(self._vector(obs))).ravel()[0])
        u = np.clip(u, -1.0, 1.0)
        # Centred action map matching the training environment:
        # a = clip(6*xi, a_min, a_max), so xi=0 holds speed (a=0).
        a = np.clip(6.0 * u, self.a_min, self.a_max)
        return float(a)
