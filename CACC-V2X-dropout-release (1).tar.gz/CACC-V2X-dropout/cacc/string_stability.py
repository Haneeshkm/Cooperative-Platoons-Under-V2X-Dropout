"""
String-stability analysis for constant-time-headway car following.

A platoon is *string stable* if disturbances do not amplify upstream, i.e. the
velocity transfer function between consecutive vehicles satisfies
|G(jw)| <= 1 for all frequencies w.

We use the canonical, citable closed-loop forms (cf. Rajamani, *Vehicle
Dynamics and Control*; Naus et al. 2010; Ploeg et al. 2014):

ACC (constant-time-headway PD law with first-order actuator lag tau):
    M(s)       = (kp + kd s) / (s (tau s + 1))
    G_acc(s)   = (M/s) / (1 + M/s + M h)
  -> string stable only for sufficiently large headway h.

CACC (predecessor-acceleration feedforward designed to invert the lag, the
Ploeg/Naus plant-inverting feedforward):
    G_cacc(s)  = 1 / (1 + h s)
  -> |G_cacc(jw)| <= 1 for ALL w and ANY h > 0.

Under intermittent V2X the feedforward is available with probability (1-p_drop);
a mean-channel approximation interpolates between the two regimes and exposes
how much dropout the platoon can tolerate before string stability collapses.
A nonlinear time-domain amplification metric is also provided for the full
stochastic / mixed-traffic rollouts where the linear assumptions break.
"""
from __future__ import annotations
import numpy as np


def acc_velocity_tf(omega, kp, kd, h, tau):
    """ACC velocity transfer function G_acc(jw)."""
    s = 1j * np.asarray(omega, dtype=complex)
    s = np.where(s == 0, 1e-9j, s)
    M = (kp + kd * s) / (s * (tau * s + 1.0))
    return (M / s) / (1.0 + M / s + M * h)


def cacc_velocity_tf(omega, h):
    """Ideal CACC velocity transfer function with plant-inverting feedforward."""
    s = 1j * np.asarray(omega, dtype=complex)
    return 1.0 / (1.0 + h * s)


def effective_tf(omega, p_drop, kp, kd, h_acc, tau, h_cacc):
    """Mean-channel TF under i.i.d. dropout: blends CACC (comms up) and ACC fallback."""
    g_cacc = cacc_velocity_tf(omega, h_cacc)
    g_acc = acc_velocity_tf(omega, kp, kd, h_acc, tau)
    return (1.0 - p_drop) * g_cacc + p_drop * g_acc


def sup_magnitude(tf_values):
    return float(np.max(np.abs(tf_values)))


def string_stability_index_freq(mode="cacc", kp=0.2, kd=0.7, h=0.6, tau=0.3,
                                p_drop=0.0, h_acc=1.5, w_max=15.0, n=8000):
    """Return (sup|G|, omega_grid, |G(omega)|) for the requested controller."""
    w = np.linspace(1e-3, w_max, n)
    if mode == "acc":
        tf = acc_velocity_tf(w, kp, kd, h, tau)
    elif mode == "cacc":
        tf = cacc_velocity_tf(w, h)
    elif mode == "effective":
        tf = effective_tf(w, p_drop, kp, kd, h_acc, tau, h)
    else:
        raise ValueError(mode)
    mag = np.abs(tf)
    return sup_magnitude(tf), w, mag


# backwards-compatible alias used by some notebooks
def velocity_tf(omega, kp, kd, h, tau, kff=0.0):
    return cacc_velocity_tf(omega, h) if kff > 0 else acc_velocity_tf(omega, kp, kd, h, tau)


# --------------------------------------------------------------------------- #
def time_domain_amplification(log, ref_index=0):
    """Empirical peak-to-peak velocity deviation per vehicle, normalised by the lead."""
    vel = log["vel"]
    p2p = np.ptp(vel, axis=0)
    ref = max(p2p[ref_index], 1e-6)
    return p2p / ref


def disturbance_growth(log):
    """Max upstream peak-to-peak velocity deviation / lead's (>1 => amplifying)."""
    amp = time_domain_amplification(log)
    return float(np.max(amp[1:])) if len(amp) > 1 else 0.0


def steady_state_amplification(log, frac=0.5, ref_index=0):
    """Peak-to-peak velocity oscillation per vehicle over the back `frac` of the
    rollout (transients excluded), normalised by the lead. This is the standard
    steady-state string-stability probe for a sustained sinusoidal disturbance.
    """
    vel = log["vel"]
    k0 = int(vel.shape[0] * frac)
    seg = vel[k0:]
    amp = seg.max(axis=0) - seg.min(axis=0)
    ref = max(amp[ref_index], 1e-6)
    return amp / ref


def steady_state_growth(log, frac=0.5):
    amp = steady_state_amplification(log, frac=frac)
    return float(np.max(amp[1:])) if len(amp) > 1 else 0.0
