"""
Intelligent Driver Model (IDM) for human-driven vehicles.

IDM is the standard, well-validated car-following model used to represent
human drivers in mixed-autonomy traffic studies (Treiber, Hennecke & Helbing,
2000). It is intentionally *non-cooperative*: it reacts only to the gap and
relative speed of the immediate leader (i.e. onboard perception only, no V2X),
which makes it the right adversary for a robust CACC study.

    a = a_max * [ 1 - (v / v0)^delta - (s* / s)^2 ]
    s* = s0 + max(0, v*T + v*dv / (2*sqrt(a_max*b)))

where dv = v - v_lead (closing rate, positive when approaching).
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np


@dataclass
class IDMParams:
    v0: float = 30.0     # desired (free-flow) speed [m/s]
    T: float = 1.5       # safe time headway [s]
    a_max: float = 1.5   # maximum acceleration [m/s^2]
    b: float = 2.0       # comfortable deceleration [m/s^2]
    delta: float = 4.0   # acceleration exponent [-]
    s0: float = 2.0      # minimum bumper-to-bumper gap [m]
    b_emergency: float = 6.0  # hard braking limit [m/s^2]


def idm_accel(v, v_lead, gap, p: IDMParams):
    """Return IDM commanded acceleration [m/s^2].

    v     : own speed [m/s]
    v_lead: leader speed [m/s] (None / np.inf gap => free road)
    gap   : bumper-to-bumper gap to leader [m]
    """
    gap = max(gap, 1e-2)
    dv = v - v_lead
    s_star = p.s0 + max(0.0, v * p.T + v * dv / (2.0 * np.sqrt(p.a_max * p.b)))
    a_free = 1.0 - (v / max(p.v0, 1e-3)) ** p.delta
    a_int = -(s_star / gap) ** 2
    a = p.a_max * (a_free + a_int)
    return float(np.clip(a, -p.b_emergency, p.a_max))


def sample_idm_population(n, rng, heterogeneous=True):
    """Sample a heterogeneous population of human drivers (calibrated-style spread)."""
    drivers = []
    for _ in range(n):
        if heterogeneous:
            p = IDMParams(
                v0=float(rng.normal(30.0, 2.5)),
                T=float(np.clip(rng.normal(1.5, 0.3), 0.8, 2.5)),
                a_max=float(np.clip(rng.normal(1.5, 0.3), 0.8, 2.5)),
                b=float(np.clip(rng.normal(2.0, 0.3), 1.2, 3.0)),
                s0=float(np.clip(rng.normal(2.0, 0.4), 1.0, 3.5)),
            )
        else:
            p = IDMParams()
        drivers.append(p)
    return drivers
