"""
V2X communication channel model.

Models the imperfect vehicle-to-everything link that CACC depends on:

  * Bernoulli packet dropout with probability p_drop (i.i.d. per message), or
  * Gilbert-Elliott bursty dropout (good/bad state Markov chain) for the
    correlated losses seen under shadowing / handover.
  * A fixed transport delay D (e.g. 100 ms) implemented as a FIFO buffer.

When a message is available, the receiver obtains the *delayed* predecessor
acceleration and velocity. When it is dropped (or none has arrived yet), the
channel returns a masked reading and sets ``received=False`` so that a
dropout-aware policy can fall back to onboard sensing.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from collections import deque
import numpy as np


@dataclass
class V2XParams:
    p_drop: float = 0.0          # i.i.d. dropout probability (Bernoulli mode)
    delay_steps: int = 0         # transport delay in simulation steps
    mode: str = "bernoulli"      # 'bernoulli' | 'gilbert_elliott' | 'perfect'
    # Gilbert-Elliott parameters (burst losses)
    p_gb: float = 0.05           # P(good -> bad)
    p_bg: float = 0.30           # P(bad -> good)
    drop_good: float = 0.02      # loss prob in good state
    drop_bad: float = 0.80       # loss prob in bad state


class V2XChannel:
    """One simplex link carrying the predecessor's (accel, velocity) message."""

    def __init__(self, params: V2XParams, rng: np.random.Generator):
        self.p = params
        self.rng = rng
        self._buf = deque()          # pending (msg, deliver_at_step) tuples
        self._t = 0
        self._last = None            # last successfully received payload
        self._ge_bad = False         # Gilbert-Elliott state

    def reset(self):
        self._buf.clear()
        self._t = 0
        self._last = None
        self._ge_bad = False

    def _is_dropped(self):
        if self.p.mode == "perfect":
            return False
        if self.p.mode == "gilbert_elliott":
            # advance the channel state
            if self._ge_bad:
                if self.rng.random() < self.p.p_bg:
                    self._ge_bad = False
            else:
                if self.rng.random() < self.p.p_gb:
                    self._ge_bad = True
            loss = self.p.drop_bad if self._ge_bad else self.p.drop_good
            return self.rng.random() < loss
        # default bernoulli
        return self.rng.random() < self.p.p_drop

    def transmit(self, payload: dict):
        """Sender pushes a payload (e.g. {'a': ..., 'v': ...}) this step."""
        if not self._is_dropped():
            self._buf.append((payload, self._t + self.p.delay_steps))

    def receive(self):
        """Receiver pulls the freshest delivered payload (called each step).

        Returns (payload_or_mask, received_flag).
        """
        delivered = None
        # deliver everything whose time has come; keep the freshest
        while self._buf and self._buf[0][1] <= self._t:
            delivered = self._buf.popleft()[0]
        self._t += 1
        if delivered is not None:
            self._last = delivered
            return delivered, True
        return {"a": 0.0, "v": 0.0}, False
