"""
Performance metrics computed from a platoon rollout log.

Reports the headline indicators a reviewer expects: safety (minimum gap,
minimum time-to-collision, collisions), comfort (RMS / peak jerk), and EV
energy (kWh and kWh/100 km, with regenerated energy already netted out by the
powertrain model), plus the string-stability summary.
"""
from __future__ import annotations
import numpy as np
from .string_stability import (disturbance_growth, time_domain_amplification,
                               steady_state_growth)


def time_to_collision(gap, v, v_lead):
    """TTC [s]; +inf when not closing."""
    closing = v - v_lead
    with np.errstate(divide="ignore", invalid="ignore"):
        ttc = np.where(closing > 1e-3, gap / closing, np.inf)
    return ttc


def compute_metrics(log, vehicle_params=None):
    cfg = log["config"]
    dt = cfg.dt
    n = cfg.n_followers
    vel = log["vel"]
    acc = log["acc"]
    gap = log["gap"]

    # ---- safety ----
    min_gap = float(np.min(gap))
    collisions = int(np.sum(log["collisions"] > 0))
    # min TTC across all followers
    ttc_min = np.inf
    for i in range(n):
        ttc = time_to_collision(gap[:, i], vel[:, i + 1], vel[:, i])
        ttc_min = min(ttc_min, float(np.min(ttc)))

    # ---- comfort: jerk = d(acc)/dt for followers ----
    jerk = np.diff(acc[:, 1:], axis=0) / dt
    rms_jerk = float(np.sqrt(np.mean(jerk ** 2)))
    peak_jerk = float(np.max(np.abs(jerk)))

    # ---- energy (EV) ----
    energy_J = log["energy_J"]                     # (steps, n)
    total_J = energy_J.sum()
    # distance travelled by followers
    dist_m = (vel[:, 1:].sum(axis=0) * dt)         # per follower
    total_dist = float(dist_m.sum())
    kWh = total_J / 3.6e6
    kWh_per_100km = (kWh / max(total_dist / 1000.0, 1e-6)) * 100.0

    # ---- string stability (steady-state probe; matches the headline figures) ----
    growth = steady_state_growth(log)

    return {
        "min_gap_m": min_gap,
        "min_ttc_s": ttc_min,
        "collisions": collisions,
        "collision_free": collisions == 0,
        "rms_jerk_m_s3": rms_jerk,
        "peak_jerk_m_s3": peak_jerk,
        "energy_kWh": float(kWh),
        "energy_kWh_per_100km": float(kWh_per_100km),
        "string_growth": growth,
        "string_stable": growth <= 1.0 + 1e-6,
    }


def metrics_table(results: dict):
    """results: {label: metrics_dict} -> formatted text table."""
    cols = ["min_gap_m", "min_ttc_s", "collisions", "rms_jerk_m_s3",
            "energy_kWh_per_100km", "string_growth", "string_stable"]
    header = f"{'controller':<16}" + "".join(f"{c:>22}" for c in cols)
    lines = [header, "-" * len(header)]
    for label, m in results.items():
        row = f"{label:<16}"
        for c in cols:
            v = m[c]
            if isinstance(v, bool):
                row += f"{str(v):>22}"
            elif isinstance(v, (int, np.integer)):
                row += f"{v:>22d}"
            else:
                row += f"{v:>22.3f}"
        lines.append(row)
    return "\n".join(lines)
