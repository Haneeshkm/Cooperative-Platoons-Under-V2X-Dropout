"""
Single-lane platoon simulator for mixed human-RL traffic with V2X links.

Layout (positions decrease down the platoon):

    [lead] --gap1--> [veh 1] --gap2--> [veh 2] --> ... --> [veh N]

* Vehicle 0 is the *lead* and follows a prescribed velocity profile -- it is the
  disturbance source used to probe string stability.
* Each follower is either ``human`` (IDM, onboard-only) or ``controlled``
  (uses a supplied controller: CACC / PID / MPC / RL).
* A controlled vehicle receives a V2X message (predecessor accel & velocity)
  ONLY if its immediate predecessor is also V2X-equipped (controlled). Losing a
  message, or sitting behind a human vehicle, forces onboard-only operation.

The simulator records per-vehicle trajectories and computes collision events,
so downstream notebooks can evaluate safety, comfort, energy and string
stability from a single rollout.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable, List, Optional
import numpy as np

from .dynamics import VehicleParams, step_longitudinal, desired_spacing
from .idm import IDMParams, idm_accel
from .v2x import V2XParams, V2XChannel


VEHICLE_LENGTH = 4.5  # [m]


@dataclass
class PlatoonConfig:
    n_followers: int = 7
    dt: float = 0.1
    T: float = 60.0
    init_gap: float = 25.0       # initial bumper-to-bumper gap [m]
    init_speed: float = 25.0     # initial common speed [m/s]
    vehicle_length: float = VEHICLE_LENGTH
    collision_gap: float = 0.0   # gap at or below which a collision is logged


class Platoon:
    def __init__(self, config: PlatoonConfig,
                 lead_profile: Callable[[float], float],
                 types: List[str],
                 controllers: list,
                 human_params: Optional[List[IDMParams]] = None,
                 v2x_params: Optional[V2XParams] = None,
                 veh_params: Optional[VehicleParams] = None,
                 gradient_profile: Optional[Callable[[float], float]] = None,
                 rng: Optional[np.random.Generator] = None):
        """
        types        : list of length n_followers, each 'human' or 'controlled'
        controllers  : list of length n_followers; entry is a controller object
                       for 'controlled' vehicles, None for 'human'
        human_params : list of IDMParams aligned with 'human' entries (or one shared)
        """
        self.cfg = config
        self.lead_profile = lead_profile
        self.types = types
        self.controllers = controllers
        self.vp = veh_params or VehicleParams()
        self.v2xp = v2x_params or V2XParams(mode="perfect")
        self.gradient = gradient_profile or (lambda t: 0.0)
        self.rng = rng or np.random.default_rng(0)

        n = config.n_followers
        if human_params is None:
            human_params = [IDMParams()] * n
        self.human_params = human_params

        # one V2X channel feeding each follower from its predecessor
        self.channels = [V2XChannel(self.v2xp, self.rng) for _ in range(n)]
        self.msg_age = np.zeros(n)

    # ------------------------------------------------------------------ #
    def _v2x_equipped(self, idx):
        """idx in 0..n-1 (follower index). Predecessor is the lead if idx==0."""
        if idx == 0:
            return True  # lead broadcasts (treated as cooperative reference)
        return self.types[idx - 1] == "controlled"

    def run(self):
        cfg = self.cfg
        n = cfg.n_followers
        steps = int(round(cfg.T / cfg.dt))
        L = cfg.vehicle_length

        # ---- initial conditions: evenly spaced, common speed ----
        v0 = cfg.init_speed
        pos = np.zeros(n + 1)
        for i in range(1, n + 1):
            pos[i] = pos[i - 1] - (cfg.init_gap + L)
        vel = np.full(n + 1, v0)
        acc = np.zeros(n + 1)

        for c in self.controllers:
            if c is not None and hasattr(c, "reset"):
                c.reset()
        for ch in self.channels:
            ch.reset()
        self.msg_age[:] = 0.0

        # ---- logs ----
        log = {
            "t": np.arange(steps) * cfg.dt,
            "pos": np.zeros((steps, n + 1)),
            "vel": np.zeros((steps, n + 1)),
            "acc": np.zeros((steps, n + 1)),
            "gap": np.zeros((steps, n)),
            "a_cmd": np.zeros((steps, n)),
            "v2x_received": np.zeros((steps, n), dtype=bool),
            "energy_J": np.zeros((steps, n)),
            "collision_step": -1,
            "collisions": np.zeros(n, dtype=int),
        }

        for k in range(steps):
            t = k * cfg.dt
            # ---- lead vehicle follows its prescribed profile ----
            v_lead_target = self.lead_profile(t)
            a_lead = (v_lead_target - vel[0]) / cfg.dt
            a_lead = float(np.clip(a_lead, self.vp.a_min, self.vp.a_max))
            acc[0] = a_lead
            vel[0] = float(np.clip(v_lead_target, 0.0, self.vp.v_max))
            pos[0] = pos[0] + vel[0] * cfg.dt

            # ---- predecessors broadcast their CURRENT state on V2X ----
            for i in range(n):
                if self._v2x_equipped(i):
                    self.channels[i].transmit({"a": float(acc[i]), "v": float(vel[i])})

            a_cmds = np.zeros(n)
            for i in range(n):                       # follower i -> vehicle index i+1
                gap = pos[i] - pos[i + 1] - L
                v = vel[i + 1]
                v_pred = vel[i]
                payload, received = self.channels[i].receive()
                if not self._v2x_equipped(i):
                    received = False
                self.msg_age[i] = 0.0 if received else self.msg_age[i] + 1.0

                if self.types[i] == "human":
                    a_cmd = idm_accel(v, v_pred, gap, self.human_params[i])
                else:
                    obs = {
                        "gap": gap, "v": v, "v_lead": v_pred,
                        "a_self": acc[i + 1], "a_lead_onboard": acc[i],
                        "dt": cfg.dt,
                        "v2x_received": received,
                        "v2x_a": payload["a"], "v2x_v": payload["v"],
                        "dropout_flag": 0.0 if received else 1.0,
                        "msg_age": min(self.msg_age[i], 20.0) / 20.0,
                        "theta": self.gradient(t),
                    }
                    a_cmd = self.controllers[i](obs)

                a_cmds[i] = a_cmd
                log["gap"][k, i] = gap
                log["a_cmd"][k, i] = a_cmd
                log["v2x_received"][k, i] = received
                if gap <= cfg.collision_gap:
                    log["collisions"][i] += 1
                    if log["collision_step"] < 0:
                        log["collision_step"] = k

            # ---- integrate followers ----
            for i in range(n):
                theta = self.gradient(t)
                state = (pos[i + 1], vel[i + 1], acc[i + 1])
                (p_new, v_new, a_new), e = step_longitudinal(
                    state, a_cmds[i], theta, cfg.dt, self.vp)
                pos[i + 1], vel[i + 1], acc[i + 1] = p_new, v_new, a_new
                log["energy_J"][k, i] = e

            log["pos"][k] = pos
            log["vel"][k] = vel
            log["acc"][k] = acc

        log["config"] = cfg
        log["types"] = list(self.types)
        return log
