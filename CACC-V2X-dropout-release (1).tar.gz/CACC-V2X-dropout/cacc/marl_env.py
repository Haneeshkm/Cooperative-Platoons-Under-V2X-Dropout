"""
Multi-agent RL environment for robust CACC under V2X dropout in mixed traffic.

Parallel multi-agent API (reset / step) over the *controlled* vehicles in a
single-lane platoon. Human vehicles (IDM) are part of the environment dynamics,
not learning agents, which creates the heterogeneous, partially observable
setting the paper targets.

Per-agent observation (physics-aware + comms-aware), all normalised:
    [ gap, v_ego, v_pred(radar), a_ego, a_pred(radar),
      v2x_a, v2x_v, dropout_flag, msg_age ]

Action: scalar commanded acceleration in [-1, 1] (scaled to actuator range).

Reward (per agent) = local multi-objective + shared string-stability term:
    r_safety     : penalise small gaps / TTC violations
    r_comfort    : penalise jerk
    r_efficiency : penalise |a|
    r_string     : penalise growth of relative-velocity error vs predecessor
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np

from .dynamics import VehicleParams, step_longitudinal, desired_spacing
from .idm import IDMParams, idm_accel, sample_idm_population
from .v2x import V2XParams, V2XChannel
from .platoon import VEHICLE_LENGTH


@dataclass
class MARLConfig:
    n_followers: int = 6
    penetration: float = 1.0       # fraction controlled (RL agents); rest human
    dt: float = 0.1
    T: float = 30.0
    init_gap: float = 18.0
    init_speed: float = 25.0
    a_min: float = -6.0
    a_max: float = 3.0
    safe_gap: float = 5.0
    # reward weights (Eq. 17 of the manuscript)
    w_safety: float = 1.0
    w_comfort: float = 0.05
    w_efficiency: float = 0.02
    w_string: float = 0.3
    baseline_reward: float = 2.0   # keep cumulative reward positive (as in the paper)
    # headway-tracking term: w_track * min(kappa_track, ((gap-gap*)/c_track)^2)
    w_track: float = 0.25          # Table tab:rlhyper
    h_track: float = 0.8           # target time headway h_t [s], Table tab:rlhyper
    c_track: float = 6.0           # tracking-error scale, Table tab:rlhyper
    kappa_track: float = 4.0       # clip cap -- NOT given numerically in the text; assumed
    d0_track: float = 5.0          # standstill spacing d0, matches controllers.py CACC/PID default
    # predecessor speed-anchor term: w_vmatch * min(kappa_v, (v_i - v_{i-1})^2)
    w_vmatch: float = 0.10         # Table tab:rlhyper
    kappa_v: float = 25.0          # clip cap -- NOT given numerically in the text; assumed
    kappa_safety: float = 50.0     # clip cap for the safety term (matches prior code)
    c_safety: float = 20.0         # safety-term scale (matches prior code)
    # per-episode disturbance randomisation (domain randomisation for the lead
    # profile during TRAINING only -- evaluation should pass a fixed scenario
    # and leave this False)
    randomize_disturbance: bool = False
    disturbance_amp_range: tuple = (2.0, 4.0)     # m/s, Table tab:rlhyper
    disturbance_period_range: tuple = (10.0, 20.0)  # s, Table tab:rlhyper


OBS_KEYS = ["gap", "v", "v_lead", "a_self", "a_lead_onboard",
            "v2x_a", "v2x_v", "dropout_flag", "msg_age"]
OBS_DIM = len(OBS_KEYS)
ACT_DIM = 1


def normalize_obs(r: dict) -> np.ndarray:
    """Normalise a raw observation dict (physical units) to the network's
    input scale. Shared by the training env and any evaluation harness
    (e.g. RLPolicy in controllers.py) so a trained actor sees the same
    distribution at test time as it did during training."""
    return np.array([
        r.get("gap", 0.0) / 50.0, r.get("v", 0.0) / 35.0, r.get("v_lead", 0.0) / 35.0,
        r.get("a_self", 0.0) / 6.0, r.get("a_lead_onboard", 0.0) / 6.0,
        r.get("v2x_a", 0.0) / 6.0, r.get("v2x_v", 0.0) / 35.0,
        r.get("dropout_flag", 0.0), r.get("msg_age", 0.0),
    ], dtype=np.float32)


class PlatoonMARLEnv:
    def __init__(self, config: MARLConfig, lead_profile, v2x_params: V2XParams,
                 veh_params: VehicleParams = None, rng: np.random.Generator = None,
                 randomize_dropout=True):
        self.cfg = config
        self.lead_profile = lead_profile
        self.v2xp = v2x_params
        self.vp = veh_params or VehicleParams(a_min=config.a_min, a_max=config.a_max)
        self.rng = rng or np.random.default_rng(0)
        self.randomize_dropout = randomize_dropout
        self._assign_roles()

    def _assign_roles(self):
        n = self.cfg.n_followers
        n_ctrl = max(1, int(round(self.cfg.penetration * n)))
        mask = np.array([1] * n_ctrl + [0] * (n - n_ctrl))
        self.rng.shuffle(mask)
        self.types = ["controlled" if m else "human" for m in mask]
        self.agent_idx = [i for i, t in enumerate(self.types) if t == "controlled"]
        self.n_agents = len(self.agent_idx)

    # ------------------------------------------------------------------ #
    def reset(self, seed=None):
        if seed is not None:
            self.rng = np.random.default_rng(seed)
        self._assign_roles()
        n = self.cfg.n_followers
        L = VEHICLE_LENGTH
        self.pos = np.zeros(n + 1)
        for i in range(1, n + 1):
            self.pos[i] = self.pos[i - 1] - (self.cfg.init_gap + L)
        self.vel = np.full(n + 1, self.cfg.init_speed)
        self.acc = np.zeros(n + 1)
        self.human_params = sample_idm_population(n, self.rng)
        # optional domain randomisation of the disturbance itself (period,
        # amplitude), matching the per-episode randomisation described for
        # TRAINING; leave randomize_disturbance=False to reuse the scenario
        # passed at construction (e.g. for a fixed evaluation probe).
        if self.cfg.randomize_disturbance:
            amp = float(self.rng.uniform(*self.cfg.disturbance_amp_range))
            period = float(self.rng.uniform(*self.cfg.disturbance_period_range))
            v0 = self.cfg.init_speed
            self._active_lead_profile = lambda t, _v0=v0, _amp=amp, _period=period: (
                _v0 + _amp * np.sin(2 * np.pi * t / _period))
        else:
            self._active_lead_profile = self.lead_profile
        # optional domain randomisation of the dropout rate per episode
        p = self.v2xp.p_drop
        if self.randomize_dropout:
            p = float(self.rng.uniform(0.0, 0.6))
        ep_v2x = V2XParams(mode=self.v2xp.mode, p_drop=p,
                           delay_steps=self.v2xp.delay_steps,
                           p_gb=self.v2xp.p_gb, p_bg=self.v2xp.p_bg,
                           drop_good=self.v2xp.drop_good, drop_bad=self.v2xp.drop_bad)
        self.channels = [V2XChannel(ep_v2x, self.rng) for _ in range(n)]
        self.msg_age = np.zeros(n)
        self.k = 0
        self.steps = int(round(self.cfg.T / self.cfg.dt))
        self._prev_relvel = np.zeros(n + 1)
        return self._observations()

    def _v2x_equipped(self, idx):
        return True if idx == 0 else self.types[idx - 1] == "controlled"

    def _observations(self):
        cfg = self.cfg
        L = VEHICLE_LENGTH
        obs = {}
        self._cached = {}
        for ai in self.agent_idx:
            gap = self.pos[ai] - self.pos[ai + 1] - L
            v = self.vel[ai + 1]
            v_pred = self.vel[ai]
            if self._v2x_equipped(ai):
                self.channels[ai].transmit({"a": float(self.acc[ai]),
                                            "v": float(self.vel[ai])})
            payload, received = self.channels[ai].receive()
            if not self._v2x_equipped(ai):
                received = False
            self.msg_age[ai] = 0 if received else self.msg_age[ai] + 1
            raw = {
                "gap": gap, "v": v, "v_lead": v_pred,
                "a_self": self.acc[ai + 1], "a_lead_onboard": self.acc[ai],
                "v2x_a": payload["a"] if received else 0.0,
                "v2x_v": payload["v"] if received else 0.0,
                "dropout_flag": 0.0 if received else 1.0,
                "msg_age": min(self.msg_age[ai], 20) / 20.0,
            }
            self._cached[ai] = raw
            obs[ai] = self._normalize(raw)
        return obs

    def _normalize(self, r):
        return normalize_obs(r)

    # ------------------------------------------------------------------ #
    def step(self, actions: dict):
        cfg = self.cfg
        dt = cfg.dt
        n = cfg.n_followers
        L = VEHICLE_LENGTH
        t = self.k * dt

        # lead follows profile (randomised per-episode during training if enabled)
        v_lead_t = self._active_lead_profile(t)
        self.acc[0] = (v_lead_t - self.vel[0]) / dt
        self.vel[0] = float(np.clip(v_lead_t, 0, self.vp.v_max))
        self.pos[0] += self.vel[0] * dt

        a_cmds = np.zeros(n)
        for i in range(n):
            if self.types[i] == "human":
                gap = self.pos[i] - self.pos[i + 1] - L
                a_cmds[i] = idm_accel(self.vel[i + 1], self.vel[i], gap,
                                      self.human_params[i])
            else:
                u = float(np.clip(np.asarray(actions[i]).ravel()[0], -1, 1))
                # Centred action map (Sec. 5, Training): a = clip(6*xi, a_min, a_max)
                # so that xi=0 holds speed; asymmetric bounds inherited from the
                # actuator limits. NOT the same as a linear interpolation between
                # [a_min, a_max], which would make xi=0 command constant braking.
                a_cmds[i] = float(np.clip(6.0 * u, cfg.a_min, cfg.a_max))

        prev_acc = self.acc.copy()
        energy = np.zeros(n)
        for i in range(n):
            state = (self.pos[i + 1], self.vel[i + 1], self.acc[i + 1])
            (p_new, v_new, a_new), e = step_longitudinal(state, a_cmds[i], 0.0, dt, self.vp)
            self.pos[i + 1], self.vel[i + 1], self.acc[i + 1] = p_new, v_new, a_new
            energy[i] = e

        # ---- rewards ----
        rewards, infos = {}, {}
        relvel = self.vel[:-1] - self.vel[1:]  # predecessor - ego, per follower
        for ai in self.agent_idx:
            gap = self.pos[ai] - self.pos[ai + 1] - L
            v = self.vel[ai + 1]
            v_lead_local = self.vel[ai]
            jerk = (self.acc[ai + 1] - prev_acc[ai + 1]) / dt
            # bounded safety penalty (well-conditioned for RL); sharp but clipped
            r_safety = -cfg.w_safety * min(cfg.kappa_safety,
                                           cfg.c_safety * max(0.0, cfg.safe_gap - gap))
            r_comfort = -cfg.w_comfort * jerk ** 2
            r_eff = -cfg.w_efficiency * abs(a_cmds[ai])
            # headway-tracking term: target time-headway spacing gap* = d0 + h_t*v
            gap_star = cfg.d0_track + cfg.h_track * v
            r_track = -cfg.w_track * min(cfg.kappa_track,
                                         ((gap - gap_star) / cfg.c_track) ** 2)
            # predecessor speed-anchor: keep the follower matched to its
            # predecessor's speed (prevents a slow-crawl reward optimum)
            r_vmatch = -cfg.w_vmatch * min(cfg.kappa_v, (v - v_lead_local) ** 2)
            # string term: penalise amplification of relative-velocity vs predecessor
            amp = abs(relvel[ai]) - abs(relvel[ai - 1] if ai >= 1 else relvel[ai])
            r_string = -cfg.w_string * max(0.0, amp)
            rewards[ai] = float(cfg.baseline_reward + r_safety + r_comfort + r_eff
                                + r_track + r_vmatch + r_string)
            infos[ai] = {"gap": gap, "energy": energy[ai], "collision": gap <= 0.0}

        collided = any(infos[ai]["collision"] for ai in self.agent_idx)
        self.k += 1
        done = (self.k >= self.steps) or collided
        if collided:
            for ai in self.agent_idx:
                rewards[ai] -= 50.0  # terminal collision cost (bounded)
        obs = self._observations() if not done else {ai: np.zeros(OBS_DIM, np.float32)
                                                     for ai in self.agent_idx}
        dones = {ai: done for ai in self.agent_idx}
        return obs, rewards, dones, infos
