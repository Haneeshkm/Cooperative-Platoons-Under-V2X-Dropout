"""
Lead-vehicle velocity profiles -- the disturbance source for the platoon.

Each factory returns a callable v_lead(t) [m/s]. These mirror (and extend) the
scenarios in the published paper: highway cruise, a single braking pulse for
string-stability probing, stop-and-go, a sinusoidal sweep, and an
emergency-braking event.
"""
from __future__ import annotations
import numpy as np


def highway_cruise(v=27.0, amp=1.0, period=20.0):
    return lambda t: v + amp * np.sin(2 * np.pi * t / period)


def velocity_pulse(v=25.0, dip=5.0, t0=10.0, dur=4.0):
    """A single smooth brake-and-recover pulse -- the standard string-stability probe."""
    def prof(t):
        if t0 <= t < t0 + dur:
            phase = (t - t0) / dur
            return v - dip * np.sin(np.pi * phase)
        return v
    return prof


def stop_and_go(v_hi=22.0, v_lo=3.0, period=24.0):
    def prof(t):
        ph = (t % period) / period
        return v_lo + 0.5 * (v_hi - v_lo) * (1 - np.cos(2 * np.pi * ph))
    return prof


def sinusoidal_sweep(v=25.0, amp=4.0, f0=0.05, f1=0.5, T=60.0):
    """Chirp: sweeps disturbance frequency to expose the worst-case amplification."""
    def prof(t):
        f = f0 + (f1 - f0) * (t / T)
        return v + amp * np.sin(2 * np.pi * f * t)
    return prof


def emergency_brake(v=25.0, v_min=5.0, t0=10.0, dur=2.0, hold=6.0):
    def prof(t):
        if t < t0:
            return v
        if t < t0 + dur:
            return v + (v_min - v) * (t - t0) / dur
        if t < t0 + dur + hold:
            return v_min
        ramp = min(1.0, (t - (t0 + dur + hold)) / dur)
        return v_min + (v - v_min) * ramp
    return prof


def sinusoidal_gradient(amp_deg=5.7, period=20.0):
    """Road gradient profile theta(t) [rad] for slope-handling tests."""
    amp = np.deg2rad(amp_deg)
    return lambda t: amp * np.sin(2 * np.pi * t / period)


SCENARIOS = {
    "highway_cruise": highway_cruise,
    "velocity_pulse": velocity_pulse,
    "stop_and_go": stop_and_go,
    "sinusoidal_sweep": sinusoidal_sweep,
    "emergency_brake": emergency_brake,
}
