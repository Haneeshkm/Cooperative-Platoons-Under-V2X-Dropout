"""
Regression test for the RNG-continuity bug documented in CORRECTIONS.md, item 5.

Training must produce the SAME trajectory whether run in one continuous process
or split across multiple resumed chunks, given the same seed. This was
violated by an earlier version that reseeded numpy/torch's global RNG on every
resume (not just on cold start), which silently produced a different training
outcome depending on where chunk boundaries happened to fall -- concretely, it
flipped one seed's final policy from string-stable to string-unstable purely
because of how the training run had been chunked, not because of anything
about the seed itself. Never remove this test without re-verifying the
underlying bug can't reappear.
"""
import sys
import os
import numpy as np
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from train import build, run_one_episode, save_checkpoint, load_checkpoint  # noqa: E402


def _continuous_run(seed, n_episodes):
    torch.set_num_threads(1)
    env, algo, buf = build(seed, hide_raw_comm=False)
    return [run_one_episode(env, algo, buf, ep, seed, 150) for ep in range(n_episodes)]


def _chunked_run(seed, n_episodes, chunk_size, tmp_path):
    torch.set_num_threads(1)
    ckpt_path = str(tmp_path / "ckpt.pt")
    env, algo, buf = build(seed, hide_raw_comm=False)
    ep_returns = []
    ep = 0
    while ep < n_episodes:
        # Each "chunk" is a fresh build() call followed by a checkpoint load,
        # exactly mimicking a new process resuming from disk.
        if ep > 0:
            env, algo, buf = build(seed, hide_raw_comm=False)  # cold-start reseed...
            ep, ep_returns, _ = load_checkpoint(ckpt_path, algo, buf)  # ...then overridden
        target = min(n_episodes, ep + chunk_size)
        while ep < target:
            ep_returns.append(run_one_episode(env, algo, buf, ep, seed, 150))
            ep += 1
        if ep < n_episodes:
            save_checkpoint(ckpt_path, algo, buf, ep, ep_returns, False, 0.0)
    return ep_returns


def test_chunked_training_matches_continuous_training(tmp_path):
    seed = 12345
    n_episodes = 16
    continuous = _continuous_run(seed, n_episodes)
    chunked = _chunked_run(seed, n_episodes, chunk_size=5, tmp_path=tmp_path)
    np.testing.assert_allclose(continuous, chunked, rtol=1e-5,
        err_msg="Chunked and continuous training diverged -- the RNG-continuity "
                "fix in train.py's save/load_checkpoint has regressed.")
