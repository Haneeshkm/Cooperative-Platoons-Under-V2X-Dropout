"""
Architecture and correctness checks for the TD3 implementation.

These formalise the manual sanity checks run during development (see
CORRECTIONS.md) as a permanent regression suite: run this after touching
cacc/maddpg.py or cacc/marl_env.py, before trusting any new training run.
"""
import numpy as np
import torch
import pytest

from cacc.marl_env import OBS_KEYS, OBS_DIM
from cacc.maddpg import GatedActor, TwinCritic, MADDPG, ReplayBuffer


@pytest.fixture(autouse=True)
def _seed():
    torch.manual_seed(0)
    np.random.seed(0)


def test_actor_input_dim_matches_paper_table():
    # Table "RL training specification": actor input is obs_dim + a_lead_eff = 10.
    actor = GatedActor()
    assert actor.net[0].in_features == OBS_DIM + 1 == 10


def test_critic_is_decentralised_local_twin():
    # Table "RL training specification": twin critics Q1, Q2(o_i, xi_i), LOCAL
    # only -- input dim is obs_dim + act_dim, never n_agents * (obs_dim + act_dim).
    # A centralised joint critic here would silently reintroduce the bug this
    # project's own predecessor shipped with (see CORRECTIONS.md, item 1).
    critic = TwinCritic()
    assert critic.q1[0].in_features == OBS_DIM + 1 == 10
    assert critic.q1 is not critic.q2, "critic must have two independent Q heads"


def test_hide_raw_comm_removes_v2x_fields_from_actor_input():
    full = GatedActor(hide_raw_comm=False)
    hidden = GatedActor(hide_raw_comm=True)
    assert hidden.net[0].in_features == full.net[0].in_features - 2


def test_hide_raw_comm_reduces_bypass_sensitivity():
    """With the V2X link marked down (dropout_flag=1), a TRAINED full actor can
    still move its output when the RAW v2x_a field is perturbed (the bypass
    reviewers flagged), because raw v2x_a is one of its direct input features.
    A hide_raw_comm actor structurally cannot: v2x_a is excluded from its kept
    feature indices, so a change to that raw field cannot reach net() through
    any path except the explicit gate blend. This is tested directly at the
    net() level (bypassing the untrained, randomly-initialised gate output,
    which is not a reliable thing to assert behaviour on) so the test is
    deterministic rather than dependent on random initialisation.
    """
    full = GatedActor(hide_raw_comm=False)
    hidden = GatedActor(hide_raw_comm=True)
    v2x_a_idx = OBS_KEYS.index("v2x_a")

    obs_a = torch.zeros(1, OBS_DIM)
    obs_b = obs_a.clone()
    obs_b[0, v2x_a_idx] = 5.0   # differ ONLY in the raw v2x_a field
    a_lead_eff = torch.zeros(1, 1)  # hold the gate-blend term fixed for both calls

    full_out_a = full.net(torch.cat([obs_a[..., full._keep_idx], a_lead_eff], dim=-1))
    full_out_b = full.net(torch.cat([obs_b[..., full._keep_idx], a_lead_eff], dim=-1))
    hidden_out_a = hidden.net(torch.cat([obs_a[..., hidden._keep_idx], a_lead_eff], dim=-1))
    hidden_out_b = hidden.net(torch.cat([obs_b[..., hidden._keep_idx], a_lead_eff], dim=-1))

    assert not torch.allclose(full_out_a, full_out_b), (
        "sanity: with v2x_a a direct feature, changing it should change the full "
        "actor's output for a generic random initialisation")
    assert torch.equal(hidden_out_a, hidden_out_b), (
        "hide_raw_comm's kept-feature slice must be IDENTICAL for two observations "
        "that differ only in the excluded v2x_a field -- if this fails, hide_raw_comm "
        "is leaking the raw field back in somehow")


def test_centred_action_map_holds_speed_at_zero_action():
    """xi=0 must command ~0 acceleration (hold speed), NOT -1.5 m/s^2 constant
    braking. This was a real bug (see CORRECTIONS.md, item 3): the original
    implementation used a=a_min + 0.5*(u+1)*(a_max-a_min), which is centred at
    -1.5 m/s^2, not 0."""
    from cacc.marl_env import PlatoonMARLEnv, MARLConfig
    from cacc.v2x import V2XParams
    from cacc import scenarios

    mcfg = MARLConfig(n_followers=2, penetration=1.0, T=5.0)
    env = PlatoonMARLEnv(mcfg, scenarios.highway_cruise(v=25.0, amp=0.0),
                          V2XParams(mode="perfect"), rng=np.random.default_rng(0),
                          randomize_dropout=False)
    env.reset(seed=0)
    zero_actions = {ai: np.array([0.0]) for ai in env.agent_idx}
    for _ in range(20):
        env.step(zero_actions)
    assert np.abs(env.acc[1:]).max() < 0.05


def test_rl_policy_centred_action_map():
    from cacc.controllers import RLPolicy
    class ConstZero:
        def __call__(self, x):
            return np.array([0.0])
    pol = RLPolicy(ConstZero(), OBS_KEYS)
    a = pol({k: 0.0 for k in OBS_KEYS})
    assert abs(a) < 1e-9


def test_reward_includes_tracking_and_vmatch_terms():
    """The original release's reward was missing the headway-tracking and
    predecessor speed-anchor terms from Eq. (17) (CORRECTIONS.md, item 2).
    This doesn't re-derive the reward value, just checks the config carries
    the corresponding weights and that a step executes without error."""
    from cacc.marl_env import MARLConfig, PlatoonMARLEnv
    from cacc.v2x import V2XParams
    from cacc import scenarios

    cfg = MARLConfig(n_followers=1, penetration=1.0, T=2.0)
    assert hasattr(cfg, "w_track") and cfg.w_track > 0
    assert hasattr(cfg, "w_vmatch") and cfg.w_vmatch > 0

    env = PlatoonMARLEnv(cfg, scenarios.highway_cruise(v=25.0, amp=0.0),
                          V2XParams(mode="perfect"), rng=np.random.default_rng(0),
                          randomize_dropout=False)
    env.reset(seed=0)
    _, rew, _, _ = env.step({env.agent_idx[0]: np.array([-1.0])})
    assert np.isfinite(rew[env.agent_idx[0]])


def test_td3_gradients_flow_and_stay_finite():
    n_agents = 4
    algo = MADDPG(n_agents)
    buf = ReplayBuffer(5000, n_agents)
    rng = np.random.default_rng(1)
    for _ in range(400):
        o = rng.normal(size=(n_agents, OBS_DIM)).astype(np.float32)
        a = rng.uniform(-1, 1, size=(n_agents, 1)).astype(np.float32)
        r = rng.normal(size=(n_agents,)).astype(np.float32)
        o2 = rng.normal(size=(n_agents, OBS_DIM)).astype(np.float32)
        d = np.zeros(n_agents, dtype=np.float32)
        buf.push(o, a, r, o2, d)
    losses = []
    for _ in range(30):
        out = algo.update(buf, batch=64)
        if out:
            losses.append(out["critic_loss"])
    assert all(np.isfinite(losses))
    assert any(p.grad is not None for p in algo.actor.parameters())


def test_delayed_actor_update_ratio():
    """TD3's delayed policy update: the actor should update on exactly every
    Nth critic step (policy_delay), not every step."""
    algo = MADDPG(2, policy_delay=2)
    buf = ReplayBuffer(1000, 2)
    rng = np.random.default_rng(2)
    for _ in range(300):
        o = rng.normal(size=(2, OBS_DIM)).astype(np.float32)
        a = rng.uniform(-1, 1, size=(2, 1)).astype(np.float32)
        r = rng.normal(size=(2,)).astype(np.float32)
        o2 = rng.normal(size=(2, OBS_DIM)).astype(np.float32)
        d = np.zeros(2, dtype=np.float32)
        buf.push(o, a, r, o2, d)
    n_actor_updates = 0
    for _ in range(20):
        out = algo.update(buf, batch=32)
        if out and out["actor_loss"] is not None:
            n_actor_updates += 1
    assert n_actor_updates == 10  # exactly half of 20, given policy_delay=2
